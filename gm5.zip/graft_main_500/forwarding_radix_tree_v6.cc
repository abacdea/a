#include <iostream>
#include <queue>
#include <stack>
#include <list>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <arpa/inet.h>
#include <nlohmann/json.hpp>

#include "./include/forwarding_radix_tree_v6.h"
#include "./include/ec.h"
#include "./include/util.h"

#define BIT_TEST(k, b)  (((uint8_t *)(k))[(b) >> 3] & (0x80 >> ((b) & 0x7)))

using namespace std;
using json = nlohmann::json;

static unsigned long base_ec_id = 1;

//static unordered_map< string, unordered_map< string, vector< string > > > prefix_to_router_forwarding;
/*
static unordered_map< unsigned long, unordered_map< string, vector< string > > > ec_id_to_graph_map;
static unordered_map< unsigned long, vector< struct radix_tree_node * > > ec_id_to_radix_tree_nodes_map;
static unordered_map< string, unsigned long > path_to_ec_id_map;
*/

/*
void ec_forwarding_graph_delete(unsigned long ec_id, string addr)
{
	vector< struct radix_tree_node * > *rtn_vec  = &ec_id_to_radix_tree_nodes_map[ec_id];

	for(int i=0;i<rtn_vec->size();i++){
		struct radix_tree_node *rtn = rtn_vec[0][i];
		if(rtn->data[0].addr == addr){
			rtn_vec->erase(rtn_vec->begin() + i);
			break;
		}
	}
}

void encap_radix_tree_travarse(struct encap_radix_tree_node **node)
{
	if(*node == NULL){
		return;
	}

	if(!(*node)->data.encap_addr.empty()){
		cout << (*node)->data.encap_addr[0] << endl;
	}

	encap_radix_tree_travarse(&(*node)->left);
	encap_radix_tree_travarse(&(*node)->right);
}
*/
/*
void show_ec_forwarding_graph(string prefix)
{
	string src;
        list< struct forwarding_link > *links;
	unordered_map< string , bool > is_visited;

	struct forwarding_graph *fw_graph = prefix_to_graph_mapper[prefix];

	for(auto l = fw_graph->links.begin(); l != fw_graph->links.end(); l++){

		if(is_visited[l->first] == true){
			continue;
		}

        	stack<string> stack;
		stack.push(l->first);

        	while(!stack.empty()){
                	src = stack.top();
                	stack.pop();

                	links = &fw_graph->links[src];

               	 	if(links->empty()){
                        	continue;
                	}

                	for(auto itr = links->begin(); itr != links->end(); itr++){
                        	struct forwarding_link link = *itr;
				is_visited[link.nexthop] = true;

                        	stack.push(link.nexthop);
                		//cout << src << " to " << link.nexthop << " via " << link.interface<< endl;
                	}
		}
	}
}
*/

/*
unsigned long compute_ec_id(string *path)
{
	int ec_id;
	
	ec_id = path_to_ec_id_map[*path];	

	if(ec_id == 0){
		path_to_ec_id_map[*path] = base_ec_id;
		base_ec_id++;

		return base_ec_id - 1;
	}
	else{
		cout << "yes" << endl;
		return ec_id;
	}
}

void rec_compute_forwarding_graph(struct radix_tree_node **node)
{
	if(*node == NULL){
		return;
	}

	if(!(*node)->data.empty()){
		string addr = (*node)->data[0].addr;

		string path;
		
		vector<struct route_data> *data = &(*node)->data;
		unordered_map< string, vector<string> > fwd_graph;

		int num = data[0].size();
		
		for(int i=0;i<num;i++){
			path += data[0][i].device;
			for(int j=0;j<data[0][i].inf.size();j++){
				fwd_graph[data[0][i].device].push_back(data[0][i].inf[j]);
				path += data[0][i].inf[j];
			}
		}
		
		//prefix_to_router_forwarding[addr] = rt_fw;

		unsigned long ec_id = compute_ec_id(&path);
		(*node)->ec_id = ec_id;
		
		ec_id_to_graph_map[ec_id] = fwd_graph;
		ec_id_to_radix_tree_nodes_map[ec_id].push_back(*node);
	}

	rec_compute_forwarding_graph(&(*node)->left);
	rec_compute_forwarding_graph(&(*node)->right);

	return;
}

void compute_forwarding_graph(struct radix_tree *rtree)
{
	string prev_prefix;
	rec_compute_forwarding_graph(&rtree->root);

	cout << base_ec_id << endl;

	return;
}
*/

/*
using json = nlohmann::json;

void l2_topology_create(unordered_map< string, pair < string, string > > l2_topology, string path)
{
	std::ifstream ifs(path);

	json jf;
	
	ifs >> jf;

	pair< string, string > dev_port;

	for(int i=0;i<jf.size();i++){
		string src_device = jf[i]["node1"]["hostname"];
		string src_port = jf[i]["node1"]["interfaceName"];
		string src = src_device + src_port;
		
		dev_port.first = jf[i]["node2"]["hostname"];
		dev_port.second = jf[i]["node2"]["interfaceName"];

		l2_topology[src] = dev_port;

		src_device = jf[i]["node2"]["hostname"];
		src_port = jf[i]["node2"]["interfaceName"];
		src = src_device + src_port;

		dev_port.first = jf[i]["node1"]["hostname"];
		dev_port.second = jf[i]["node1"]["interfaceName"];

		l2_topology[src] = dev_port;
	}
}

bool inet6_lnaof(struct in6_addr *dst, struct in6_addr *src, struct in6_addr *netmask)
{
        bool has_lna = false;

        for (unsigned i = 0; i < 16; i++) {
                dst->s6_addr[i] = src->s6_addr[i] & netmask->s6_addr[i];
                has_lna |= (0 != (src->s6_addr[i] & !netmask->s6_addr[i]));
        }

        return has_lna;
}

int convert_v6addr_to_uint(string addr,struct in6_addr *masked)
{
	int ret = 0;

	int i = 0;
	while(addr[i] != '/'){
		i++;
	}
	
	string str_prefix = addr.substr(0,i);
	
	const char *prefix = str_prefix.c_str();

	int len = 0;
	for(int j=i+1;j<addr.length();j++){
		len++;
	}

	int k = 0;
	char prefix_array[len];
	for(int j=i+1;j<addr.length();j++){
		prefix_array[k] = addr[j];
		k++;
	}

	int prefix_len = atoi(prefix_array);

	
	struct in6_addr res;
	ret = inet_pton(AF_INET6, prefix, &res);
	if(ret != 1){
		perror("inet_pton: ");
		return -1;
	}

	//for(i=0;i<16;i++){
		//printf("%hhx",res.s6_addr[i]);
//	}
//	cout << endl;

	struct sockaddr_in6 netmask;
	for (long i = prefix_len, j = 0; i > 0; i -= 8, ++j){
  		netmask.sin6_addr.s6_addr[j] = i >= 8 ? 0xff : (uint64_t)(( 0xffU << ( 8 - i ) ) & 0xffU );
	}

	inet6_lnaof(masked,&res,&netmask.sin6_addr);
	
	return prefix_len;
}
*/

struct header_constraint_vec *rec_set_ec_info(struct radix_tree_node **node, struct ec_info eci, uint8_t *addr, int prefix_len, int depth)
{
	if(prefix_len == depth){
		if(*node == NULL){
			*node = new struct radix_tree_node;
		}
		
		(*node)->eci.push_back(eci);

		int size = (*node)->eci.size();
		return &((*node)->eci[size-1].hcv);
	}
	else{
		if(BIT_TEST(addr,depth)){
			//cout << "1" ;
			return rec_set_ec_info(&(*node)->right, eci, addr, prefix_len, depth+1);
		}
		else{
			//cout << "0";
			return rec_set_ec_info(&(*node)->left, eci, addr, prefix_len, depth+1);
		}
	}
}

struct header_constraint_vec *set_ec_info(struct radix_tree *rtree, struct ec_info eci, uint8_t *addr, int prefix_len)
{
	return rec_set_ec_info(&rtree->root, eci, addr, prefix_len , 0);
}

void rec_set_transition_ec_id(struct radix_tree_node **node, uint8_t *addr, int prefix_len, unsigned long tid, int depth)
{
	if(*node == NULL){
		return ;
	}

	if(!(*node)->eci.empty() && prefix_len <= depth){
		for(int i=0;i<(*node)->eci.size();i++){
			if((*node)->eci[i].transit_ec_id != 0){
				cout << "error at rec_set_transition_ec_id !" << endl;
			}
			(*node)->eci[i].transit_ec_id = tid;
		}
		
	}

	if(BIT_TEST(addr,depth)){
		return rec_set_transition_ec_id(&(*node)->right, addr, prefix_len, tid, depth+1);
	}
	else{
		return rec_set_transition_ec_id(&(*node)->left, addr, prefix_len, tid, depth+1);
	}
	
}

void set_transition_ec_id(struct radix_tree *rtree, uint8_t *addr, int prefix_len, unsigned long tid, int depth)
{
	return rec_set_transition_ec_id(&rtree->root, addr, prefix_len, tid, 0);
}

vector< struct ec_info *> rec_get_affected_ec(struct radix_tree_node **node, uint8_t *addr, int prefix_len, int depth, vector< struct ec_info *> *eci_vec)
{
	if(*node == NULL){
		return *eci_vec;
	}

	if(!(*node)->eci.empty() && prefix_len <= depth){
		for(int i=0;i<(*node)->eci.size();i++){
			eci_vec->push_back(&(*node)->eci[i]);
		}
	}

	if(BIT_TEST(addr,depth)){
		return rec_get_affected_ec(&(*node)->right, addr, prefix_len, depth+1, eci_vec);
	}
	else{
		return rec_get_affected_ec(&(*node)->left, addr, prefix_len, depth+1, eci_vec);
	}
	
}

vector< struct ec_info *> get_affected_ec(struct radix_tree *rtree, uint8_t *addr, int prefix_len)
{
	vector< struct ec_info *> eci_vec;

	return rec_get_affected_ec(&rtree->root, addr, prefix_len, 0, &eci_vec);
}

struct ec_info *rec_get_ec_info(struct radix_tree_node *node, struct radix_tree_node *prev_node, uint8_t *addr, int depth)
{
	if(node == NULL){
		if(prev_node){
			return &prev_node->eci[0];
		}
		else{
			//printf("Can not find a route\n");
			return NULL;
		}
	}

	if(!node->data.empty()){
		prev_node = node;
	}

	if(BIT_TEST(addr,depth)){
		return rec_get_ec_info(node->right, prev_node, addr, depth+1);
	}
	else{
		return rec_get_ec_info(node->left, prev_node, addr, depth+1);
	}
	
}

struct ec_info *get_ec_info(struct radix_tree *rtree, uint8_t *addr)
{
	return rec_get_ec_info(rtree->root, NULL, addr, 0);
}

/*
void rec_change_ec_id(struct radix_tree_node **node, uint8_t *addr, int prefix_len, int depth, unsigned long new_ec_id)
{
	if(prefix_len == depth){
		(*node)->eci.ec_id = new_ec_id;
		return 0;
	}
	else{
		if(BIT_TEST(addr,depth)){
			return rec_change_ec_id(&(*node)->right, addr, prefix_len, depth+1, new_ec_id);
		}
		else{
			return rec_change_ec_id(&(*node)->left, addr, prefix_len, depth+1, new_ec_id);
		}
	}
}

void change_ec_id(struct radix_tree *rtree, uint8_t *addr, int prefix_len , unsigned long new_ec_id)
{
	return rec_change_ec_id(&rtree->root, addr, prefix_len, 0, new_ec_id);
}

struct ec_info *rec_get_ec_info(struct radix_tree *rtree, uint8_t *addr, int prefix_len, int depth)
{
	if(prefix_len == depth){
		return &(*node)->eci;
	}
	else{
		if(BIT_TEST(addr,depth)){
			return rec_get_ec_info(&(*node)->right, addr, prefix_len, depth+1);
		}
		else{
			return rec_get_ec_info(&(*node)->left, addr, prefix_len, depth+1);
		}
	}
}

struct ec_info *get_ec_info(struct radix_tree *rtree, uint8_t *addr, int prefix_len)
{	
	return rec_get_ec_info(rtree, addr, prefix_len, 0);
}
*/

void set_linux_fib_to_radix_tree(string device, struct radix_tree *rtree, struct encap_radix_tree *etree, string *elms, int size, string mult_path_addr)
{
	int prefix_len;
	struct route_data data;
	struct in6_addr masked;

	if(elms[1] == "via"){	
		data.device = device;
		data.addr = elms[0];
		data.inf.push_back(elms[4]);

		prefix_len = convert_v6addr_to_uint(data.addr,&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}

		radix_tree_add(rtree,data,prefix_len,masked.s6_addr);
	}
	else if(elms[1] == "dev"){
		data.device = device;
		data.addr = elms[0];
		data.inf.push_back(elms[2]);

		prefix_len = convert_v6addr_to_uint(data.addr,&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}

		radix_tree_add(rtree,data,prefix_len,masked.s6_addr);
	}
	else if(elms[1] == "proto"){
		/*
		data.device = device;
		data.addr = elms[0];
		data.inf.push_back()

		prefix_len = convert_v6addr_to_uint(data.addr,&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}
		
		radix_tree_add(rtree,data,prefix_len,masked.s6_addr);
		*/
	}
	else if(elms[1] == "nexthop"){
		data.device = device;
		data.addr = mult_path_addr;
		data.inf.push_back(elms[5]);
		
		prefix_len = convert_v6addr_to_uint(data.addr,&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}

		radix_tree_add(rtree,data,prefix_len,masked.s6_addr);
	}
	else if(elms[1] == "nhid"){
		data.device = device;
		data.addr = mult_path_addr;
		data.inf.push_back(elms[6]);
		
		prefix_len = convert_v6addr_to_uint(data.addr,&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}

		radix_tree_add(rtree,data,prefix_len,masked.s6_addr);
	}
	/*
	else if(elms[2] == "seg6" && etree != NULL){
		int num_addr = stoi(elms[6]);

		//for(int i=0;i<num_addr;i++){
		for(int i=0;i<1;i++){
			cout << elms[8+i] << endl;
			edata.encap_addr.push_back(elms[8+i]);
		}

		edata.device = device;

		prefix_len = convert_v6addr_to_uint(elms[0],&masked);
		if(prefix_len == -1){
			cout << "error at convert_v6addr_to_uint()" << endl;
			return;
		}

		encap_radix_tree_add(etree,edata,prefix_len,masked.s6_addr);
	}
	*/
}

void read_linux_fib_to_radix_tree(string device, struct radix_tree *rtree, struct encap_radix_tree *etree, string path)
{
	int i = 0;
	int cur_idx = 0;
	int prev_idx = 0;
	string line;
	string cur_val;
	string mult_path_addr;

	ifstream read_file;
	read_file.open(path, ios::in);

	while(getline(read_file,line)){
		string iptable_elms[30];

		while(cur_idx <= line.length()-1){
			while(!isspace(line[cur_idx])){
				cur_idx++;
			}	
		
			cur_val = line.substr(prev_idx,cur_idx - prev_idx);

			iptable_elms[i] = cur_val;

			i++;
			cur_idx += 2;
			prev_idx = cur_idx-1;
		}

		if(iptable_elms[1] == "proto" || iptable_elms[1] == "nhid"){
			mult_path_addr = iptable_elms[0];
		}

		set_linux_fib_to_radix_tree(device,rtree,etree,iptable_elms,i-1,mult_path_addr);

		i = 0;
		cur_idx = 0;
		prev_idx = 0;
	}
}

void search_radix_tree(struct radix_tree_node **node, vector< string > *header_vec)
{
	if(*node != NULL){
		if(!(*node)->data.empty()){
			header_vec->push_back((*node)->data[0].addr);	
		}
		
		search_radix_tree(&(*node)->left, header_vec);
		search_radix_tree(&(*node)->right, header_vec);
	}
}

vector< string > search_headers(struct radix_tree *rtree)
{
	vector< string > header_vec;

	search_radix_tree(&rtree->root, &header_vec);

	return header_vec;
}

//for first rule insertion
int radd(struct radix_tree_node **node, struct route_data data, int prefix, uint8_t *addr, int depth)
{
	struct radix_tree_node *new_node;

	if(*node == NULL){
		new_node = new radix_tree_node;
		if(new_node == NULL){
			printf("failed to allocate radix_tree_node at radd() .\n");
		}
		*node = new_node;
		(*node)->right = NULL;
		(*node)->left = NULL;
		//(*node)->eci.ec_id = 0;
	}
	
	if(prefix == depth){
		(*node)->data.push_back(data);
		return 0;
	}
	else{
		if(BIT_TEST(addr,depth)){
			//cout << "1" ;
			return radd(&(*node)->right, data, prefix, addr, depth+1);
		}
		else{
			//cout << "0";
			return radd(&(*node)->left, data, prefix, addr, depth+1);
		}
	}
}

int radix_tree_add(struct radix_tree *rtree, struct route_data data, int prefix, uint8_t *addr)
{
	//cout << "start" << endl;
	//printf("%hhx\n",addr[0]);
	return radd(&rtree->root, data, prefix, addr, 0);
}

int radix_tree_shrink(struct radix_tree_node **cur)
{
	int lret;
	int rret;

	if(cur == NULL){
		return 0;
	}

	lret = radix_tree_shrink(&(*cur)->left); 
	rret = radix_tree_shrink(&(*cur)->right);

	if(lret || rret){
		return 1;
	}
	else{
		if((*cur)->left == NULL && (*cur)->right == NULL){
			free(*cur);
			*cur = NULL;
			return 0;
		}
		else{
			return 1;
		}
	}
}

void rdelete(struct radix_tree_node **node, int prefix, uint8_t *addr, int depth)
{
	if(*node == NULL){
		printf("No item to delete\n");
		return;
	}

	if(prefix == depth){
		if(!(*node)->data.empty()){
			radix_tree_shrink(node);
			return;
		}
		else{
			return;
		}
	}
	else{
		if(BIT_TEST(addr,depth)){
			return rdelete(&(*node)->right, prefix, addr, depth+1);
		}
		else{
			return rdelete(&(*node)->left, prefix, addr, depth+1);
		}

	}
}

void radix_tree_delete(struct radix_tree *rtree, int prefix, uint8_t *addr)
{
	return rdelete(&rtree->root, prefix, addr, 0);
}

vector<struct route_data>* rlookup(struct radix_tree_node *node, struct radix_tree_node *prev_node, uint8_t *addr, int depth)
{
	if(node == NULL){
		if(prev_node){
			return &prev_node->data;
		}
		else{
			//printf("Can not find a route\n");
			return NULL;
		}
	}

	if(!node->data.empty()){
		prev_node = node;
	}

	if(BIT_TEST(addr,depth)){
		return rlookup(node->right, prev_node, addr, depth+1);
	}
	else{
		return rlookup(node->left, prev_node, addr, depth+1);
	}

}

vector<route_data> *radix_tree_lookup(struct radix_tree *rtree, uint8_t *addr)
{
	return rlookup(rtree->root, NULL, addr, 0);
}

void radix_tree_free_node(struct radix_tree_node *node)
{
	if(node != NULL){
		radix_tree_free_node(node->left);
		radix_tree_free_node(node->right);
		free(node);
	}
}

int radix_tree_free(struct radix_tree *tree)
{
	radix_tree_free_node(tree->root);
	if(tree){
		free(tree);
	}
	return 0;
}

void radix_tree_init(struct radix_tree *rtree)
{
	if(rtree == NULL){
		rtree = new radix_tree;
	}
	else{
		printf("the radix tree is already allocated.\n");

	}

	/*
	for(int i=MAX_EC_NUMBER;i>0;i--){
		ec_index_set.push_back(i);	
	}*/

	/*
	ecs_pointer.current_index = 0;
	ecs_pointer.pointer = NULL;
	*/
}
