#include <iostream>
#include <string.h>
#include <arpa/inet.h>

#include "./include/device.h"
#include "./include/util.h"
#include "./include/forwarding_radix_tree_v6.h"
#include "./include/acl_radix_tree.h"
#include "./include/hm_radix_tree.h"
#include "./include/ec.h"

using namespace std;

struct net_device_output process_header_at_ndev(struct net_device *ndev, string dst_prefix, uint8_t *dst_addr, int prefix_len)
{		
	struct net_device_output ndo;

	ndo.name = ndev->name;
	
	for(int i=0;i<ndev->df.function.size();i++){
		//for(int j=0;j<ndev->df.function.size();j++){
		if(ndev->df.function[i] == "forward"){
			/*
			if(prefix_to_net_device[dst_prefix] == ndev->name){
				break;
			}
			*/
			
			vector< struct route_data > *data = radix_tree_lookup(ndev->fib, dst_addr);
			if(data == NULL){
				//cout << "data null at process at ndev ()" << endl;
				//cout << "net_device is " << ndev->name << endl;
				//cout << "addr is " << *dst_addr << endl;
				break;
			}

			vector< string > ports;
			for(int j=0;j<data->size();j++){
				for(int k=0;k<data[0][j].inf.size();k++){
					ports.push_back(data[0][j].inf[k]);
				}
			}
			ndo.output_port = ports;
		}
		else if(ndev->df.function[i] == "drop"){
			vector< struct acl_data > *data = acl_radix_tree_lookup(ndev->acl, dst_addr);
			
			int prefix_len;	
			struct in6_addr masked;
			struct header_constraint hc;
			
			for(int j=0;j<data->size();j++){
				
				prefix_len = convert_v6addr_to_uint(data[0][j].ft.src_addr, &masked);
				if(prefix_len == -1){
					cout << "error at v6 addr convert" << endl;
				}

				memcpy(hc.src_addr.v6_addr, masked.s6_addr, sizeof(masked.s6_addr));;
				hc.src_addr.prefix_len = prefix_len;
				
				prefix_len = convert_v6addr_to_uint(data[0][j].ft.dst_addr, &masked);
				if(prefix_len == -1){
					cout << "error at v6 addr convert" << endl;
				}

				memcpy(hc.dst_addr.v6_addr,masked.s6_addr, sizeof(masked.s6_addr));
				hc.dst_addr.prefix_len = prefix_len;

				hc.src_port = data[0][j].ft.src_port;
				hc.dst_port = data[0][j].ft.dst_port;
				hc.protocol = data[0][j].ft.protocol;
				
				hc.action = "drop";
				//hc.action = data[j]->action;
			
				hc.device = ndo.name;

				ndo.hc.push_back(hc);
			}
		}
		else if(ndev->df.function[i] == "rewrite"){
			//search header modificatio tree
			//cout << "rewrite at " << ndev->name << endl;
			vector< pair< struct fixed_header, struct fixed_header> > hm_transition_vec = hm_radix_tree_get_transition(ndev->hmr, dst_addr, prefix_len, "rewrite");
	
			struct header_transition_relation htr;
		
			//cout << "size " << hm_transition_vec.size() << endl;
			for(int j=0;j<hm_transition_vec.size();j++){
				htr.device = ndev->name;
				htr.type = "rewrite";
				htr.input_hdr = hm_transition_vec[j].first;
				htr.output_hdr = hm_transition_vec[j].second;

				ndo.htr.push_back(htr);
			}
		}
		else if(ndev->df.function[i] == "encap"){
			cout << "encap at " << ndev->name << endl;
			vector< pair< struct fixed_header, struct fixed_header> > hm_transition_vec = hm_radix_tree_get_transition(ndev->hmr, dst_addr, prefix_len, "encap");
			
			struct header_transition_relation htr;
		
			for(int j=0;j<hm_transition_vec.size();j++){
				htr.device = ndev->name;
				htr.type = "encap";
				htr.input_hdr = hm_transition_vec[j].first;
				htr.output_hdr = hm_transition_vec[j].second;

				ndo.htr.push_back(htr);
			}
		}
		else if(ndev->df.function[i] == "decap"){
			cout << "decap at " << ndev->name << endl;
			vector< pair< struct fixed_header, struct fixed_header> > hm_transition_vec = hm_radix_tree_get_transition(ndev->hmr, dst_addr, prefix_len, "decap");
			
			struct header_transition_relation htr;
		
			for(int j=0;j<hm_transition_vec.size();j++){
				htr.device = ndev->name;
				htr.type = "decap";
				htr.input_hdr = hm_transition_vec[j].first;
				htr.output_hdr = hm_transition_vec[j].second;

				ndo.htr.push_back(htr);
			}

		}
	}	

	return ndo;
}

void set_net_device(struct net_device *ndev, string name, vector< string > ports)
{
	ndev->name = name;
	//ndev->port = ports;
}

void set_dataplane_function(struct net_device *ndev, string *func_type, int length)
{
	for(int i=0;i<length;i++){
		ndev->df.function.push_back(func_type[i]);	
	}
}

void set_dataplane_pipeline(struct net_device *ndev, string *func_type, int length)
{
	set_dataplane_function(ndev, func_type, length);
}
