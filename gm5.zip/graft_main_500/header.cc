#include <iostream>

using namespace std;

//bit computation
