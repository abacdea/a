#ifndef HM_H
#define HM_H

#include <vector>
#include <utility>

#include "ec.h"

using namespace std;

/*
struct fixed_header{
	string src_addr;
	string dst_addr;
	uint8_t src_port;
	uint8_t dst_port;
	uint8_t port_number;
	
	//cast (*unsigned int)
	void *option_field;
};
*/

struct hm_data{
	string action;
	pair< struct fixed_header, struct fixed_header > htr;
	//unsigned int priority;
};

struct hm_radix_tree_node{
	struct hm_radix_tree_node *left;
	struct hm_radix_tree_node *right;

	vector<struct hm_data> data;
};

struct hm_radix_tree{
	struct hm_radix_tree_node *root;
};

struct hm_radix_tree *init(struct hm_radix_tree *rtree);
int hm_radix_tree_add(struct hm_radix_tree *rtree, struct hm_data data, int prefix, uint8_t *addr);
void hm_radix_tree_delete(struct hm_radix_tree *rtree, int prefix, uint8_t *addr);
vector<hm_data>* hm_radix_tree_lookup(struct hm_radix_tree *rtree, uint8_t *addr);
int hm_radix_tree_free(struct hm_radix_tree *tree);
vector< pair< struct fixed_header, struct fixed_header > > hm_radix_tree_get_transition(struct hm_radix_tree *rtree, uint8_t *addr, int prefix, string action);

struct fixed_header *get_transit_header(struct hm_radix_tree *rtree, uint8_t *addr, string action);

#endif
