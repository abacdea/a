#ifndef DEV_H
#define DEV_H

#include <vector>
//#include "forwarding_radix_tree_v6.h"
//#include "acl_radix_tree.h"
//#include "hm_radix_tree.h"

using namespace std;

struct dataplane_function{
	//vector< string > input_port;
	vector< string > function;
	//struct dataplane_function *next_function;
};

/*
struct fixed_header{
        string src_addr;
        string dst_addr;
        uint8_t src_port;
        uint8_t dst_port;
        uint8_t protocol;
};

struct header_modification_rule{
	string action;
	struct fixed_header input_hdr;
	struct fixed__header output_hdr;
};

struct header_modification_table{
	vector< struct header_modification_rule > hmr;
};
*/

struct net_device_output{
	string name;
	vector< string > output_port;
	vector< struct header_constraint > hc;
	vector< struct header_transition_relation >  htr;
};

struct net_device{
	string name;
	//fib
	struct radix_tree *fib;
	//acl
	struct acl_radix_tree *acl;
	//header modification 
	struct hm_radix_tree *hmr;

	vector< string > port;

	struct dataplane_function df;	
	//vector< struct dataplane_function > df;	
	//vector< struct dataplane_function > input_df;	
};

void set_net_device(struct net_device *ndev, string name, vector< string > ports);
void set_dataplane_pipeline(struct net_device *ndev, string *func_type, int length);
struct net_device_output process_header_at_ndev(struct net_device *ndev, string dst_prefix, uint8_t *dst_addr, int prefix_len);

#endif
