#ifndef _DAC_H
#define _DAC_H
/*
#include <string>
#include <unordered_map>

using namespace std;


struct forwarding_link{
	string nexthop;
	string interface;
};

struct forwarding_graph{
	int id;
	unordered_map< string, list< forwarding_link > > links;	
};
*/
#endif

