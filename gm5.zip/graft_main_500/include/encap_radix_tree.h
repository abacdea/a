#include <vector>
using namespace std;

struct encap_data{
	string device;
	vector<string> encap_addr;
};

struct encap_radix_tree_node{
	struct encap_radix_tree_node *left;
	struct encap_radix_tree_node *right;

	struct encap_data data;
	//vector<encap_data> data;
};

struct encap_radix_tree{
	struct encap_radix_tree_node *root;
};

//struct encap_radix_tree *e_init(struct encap_radix_tree *rtree);
int encap_radix_tree_add(struct encap_radix_tree *rtree, struct encap_data data, int prefix, uint8_t *addr);
void encap_radix_tree_delete(struct encap_radix_tree *rtree, int prefix, uint8_t *addr);
struct encap_data* encap_radix_tree_lookup(struct encap_radix_tree *rtree, uint8_t *addr);
int encap_radix_tree_node_free(struct encap_radix_tree_node *node);
