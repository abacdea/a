#ifndef UTIL_H
#define UTIL_H

#include <unordered_map>

using namespace std;

//void l2_topology_create(unordered_map< string, string> l2_topology, string path);
bool inet6_lnaof(struct in6_addr *dst, struct in6_addr *src, struct in6_addr *netmask);
int convert_v6addr_to_uint(string addr,struct in6_addr *masked);
#endif
