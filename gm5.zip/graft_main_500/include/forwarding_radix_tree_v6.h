#ifndef FWD_RAD_H
#define FWD_RAD_H

#include <vector>
#include "ec.h"

using namespace std;

/*
struct prefix{
	uint8_t v6_addr[16];
	uint8_t prefix_len;
};

struct header_constraint{
	string device;
	string action;
	struct prefix src_addr;	
	struct prefix dst_addr;	
	uint8_t src_port;	
	uint8_t dst_port;	
	uint8_t protocol;
};

struct header_constraint_vec{
	vector< vector< struct header_constraint > > hc;
};
*/

struct route_data{
	string device;
	string addr;
	string action;
	vector<string> inf;
};

struct ec_info{
	unsigned long ec_id;
	unsigned long transit_ec_id;
	struct header_constraint_vec hcv;
};

struct radix_tree_node{
	struct radix_tree_node *left;
	struct radix_tree_node *right;

	vector< struct ec_info > eci;

	vector<route_data> data;
};

struct radix_tree{
	struct radix_tree_node *root;
};

struct radix_tree *init(struct radix_tree *rtree);
int radix_tree_add(struct radix_tree *rtree, struct route_data data, int prefix, uint8_t *addr);
void radix_tree_delete(struct radix_tree *rtree, int prefix, uint8_t *addr);
vector<route_data>* radix_tree_lookup(struct radix_tree *rtree, uint8_t *addr);
vector< string > search_headers(struct radix_tree *rtree);
int radix_tree_free(struct radix_tree *tree);
//void set_ec_info(struct radix_tree *tree, struct ec_info eci);
void initial_graph_construct(struct radix_tree *rtree, struct encap_radix_tree *etree);
void ec_forwarding_graph_free();
bool reachability_check(string prefix, string src, string dst);
void update(string prefix, struct route_data data);
void check_properties_by_headers(struct encap_radix_tree *etree);
void read_linux_fib_to_radix_tree(string device, struct radix_tree *rtree, struct encap_radix_tree *etree, string path);
void compute_forwarding_graph(struct radix_tree *rtree);
struct ec_info *get_ec_info(struct radix_tree *rtree, uint8_t *addr);
vector< struct ec_info *> get_affected_ec(struct radix_tree *rtree, uint8_t *addr, int prefix_len);
void set_transition_ec_id(struct radix_tree *rtree, uint8_t *addr, int prefix_len, unsigned long tid, int depth);
struct header_constraint_vec *set_ec_info(struct radix_tree *rtree, struct ec_info eci, uint8_t *addr, int prefix_len);

#endif
