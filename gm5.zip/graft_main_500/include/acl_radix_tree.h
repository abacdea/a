#ifndef ACL_H
#define ACL_H

#include <vector>

using namespace std;

struct five_tuple{
	string src_addr;
	string dst_addr;
	uint8_t src_port;
	uint8_t dst_port;
	uint8_t protocol;
};

struct acl_data{
	string device;
	struct five_tuple ft;
	string action;
	unsigned int priority;
};

struct acl_radix_tree_node{
	struct acl_radix_tree_node *left;
	struct acl_radix_tree_node *right;

	vector<acl_data> data;
};

struct acl_radix_tree{
	struct acl_radix_tree_node *root;
};

struct acl_radix_tree *init(struct acl_radix_tree *rtree);
int acl_radix_tree_add(struct acl_radix_tree *rtree, struct acl_data data, int prefix, uint8_t *addr);
void acl_radix_tree_delete(struct acl_radix_tree *rtree, int prefix, uint8_t *addr);
vector<acl_data>* acl_radix_tree_lookup(struct acl_radix_tree *rtree, uint8_t *addr);
int acl_radix_tree_free(struct acl_radix_tree *tree);

#endif
