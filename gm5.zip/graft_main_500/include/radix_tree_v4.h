#ifndef _DAC_H
#define _DAC_H

#include <vector>
using namespace std;

struct route_data{
	string device;
	string addr;
	vector<string> inf;
};

struct radix_tree_node{
	struct radix_tree_node *left;
	struct radix_tree_node *right;

	vector<route_data> data;
};

struct radix_tree{
	struct radix_tree_node *root;
};


struct radix_tree *init(struct radix_tree *rtree);
int radix_tree_add(struct radix_tree *rtree, struct route_data data, int prefix, uint8_t *addr);
void radix_tree_delete(struct radix_tree *rtree, int prefix, uint8_t *addr);
vector<route_data>* radix_tree_lookup(struct radix_tree *rtree, uint8_t *addr);
int radix_tree_free(struct radix_tree *tree);

#endif
