#include <vector>

using namespace std;

struct ec_info{
	unsigned long ec_id;
	unsigned long transit_ec_id;
	struct header_constraint_vec hcv;
};

struct ec_radix_tree_node{
	struct radix_tree_node *left;
	struct radix_tree_node *right;
	
	struct ec_info eci;
};

struct ec_radix_tree{
	struct radix_tree_node *root;
};

struct ec_radix_tree *init(struct radix_tree *rtree);
int radix_tree_add(struct radix_tree *rtree, struct route_data data, int prefix, uint8_t *addr);
void radix_tree_delete(struct radix_tree *rtree, int prefix, uint8_t *addr);
vector<route_data>* radix_tree_lookup(struct radix_tree *rtree, uint8_t *addr);
vector< string > search_headers(struct radix_tree *rtree);
int radix_tree_free(struct radix_tree *tree);
void initial_graph_construct(struct radix_tree *rtree, struct encap_radix_tree *etree);
void ec_forwarding_graph_free();
bool reachability_check(string prefix, string src, string dst);
void update(string prefix, struct route_data data);
void check_properties_by_headers(struct encap_radix_tree *etree);
void read_linux_fib_to_radix_tree(string device, struct radix_tree *rtree, struct encap_radix_tree *etree, string path);
void compute_forwarding_graph(struct radix_tree *rtree);
