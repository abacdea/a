#ifndef EC_H
#define EC_H

using namespace std;

#include <unordered_map>

struct fixed_header{
        string src_addr;
        string dst_addr;
        uint8_t src_port;
        uint8_t dst_port;
        uint8_t port_number;

        //cast (*unsigned int)
        void *option_field;
};

struct device_port{
	string device;
	string port;
};

/*
struct forwarding_graph{
	unordered_map< struct device_port, struct device_port > fw_links;
};
*/

struct prefix{
	uint8_t v6_addr[16];
	uint8_t prefix_len;
};

struct header_constraint{
	string device;
	string action;
	struct prefix src_addr;	
	struct prefix dst_addr;	
	uint8_t src_port;	
	uint8_t dst_port;	
	uint8_t protocol;
};

struct header_constraint_vec{
	vector< vector< struct header_constraint > > hc;
};

struct header_transition_relation{
	string device;
	string type;
	struct fixed_header input_hdr;
	struct fixed_header output_hdr;
};


/*
struct net_device_output{
	string name;
	vector< string > output_port;
	vector< struct header_constraint > hc;
	vector< struct header_transition_relation >  htr;
};
*/

struct ec_label_transition_relation{
	string vertex;
	unsigned long input_ecl;
	string type;
	unsigned long output_ecl;
};

struct ec_transition_tree_node{
	struct ec_transition_tree_node *ettn[5];

	int num;
	string device;

	unsigned int src_ec;
	unsigned int transit_ec;
};

struct ec_transition_tree{
	struct ec_transition_tree_node *root;
};

//void forwarding_update(string dst_addr, string device, string port, struct radix_tree *rtree);
void forwarding_update(uint8_t *addr, int prefix_len, string device, string port, struct radix_tree *rtree);
void forwarding_update_reach(uint8_t *addr, int prefix_len, string device, string port, struct radix_tree *rtree);
void what_if_reach(string src_dev, string src_inf, unsigned long ecl);
void what_if_loop(string src_dev, string src_inf, unsigned long ecl, int i);
void create_equivalence_class(struct radix_tree *rtree, struct net_device *ndev, int device_num, string path);
#endif
