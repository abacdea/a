#include <iostream>
#include <stack>
#include <vector>
#include <unordered_map>
#include <map>
#include <utility>
#include <arpa/inet.h>
#include <fstream>
#include <ctime>
#include <chrono>
#include <nlohmann/json.hpp>

#include "include/ec.h"
#include "include/forwarding_radix_tree_v6.h"
#include "include/hm_radix_tree.h"
#include "include/device.h"
#include "include/util.h"

using namespace std;

/*
struct forwarding_link{
	string src_device;
	string src_port;
	string dst_device;
	string dst_port;
};
*/

/*
struct forwarding_link{
	string nexthop;
	string interface;
};
*/

/*
struct device_port{
	string device;
	string port;
};

struct forwarding_graph{
	unordred_map< struct device_port, struct device_port > fw_links;
};

struct prefix{
	uint8_t v6_addr[16];
	uint8_t prefix_len;
};

struct header_constraint{
	string device;
	string action;
	struct prefix src_addr;	
	struct prefix dst_addr;	
	uint8_t src_port;	
	uint8_t dst_port;	
	uint8_t protocol;
};

struct header_constraint_vec{
	vector< vector< struct header_constraint > > hc;
};

struct header_transition_relation{
	string device;
	string type;
	struct fixed_header input_hdr;
	struct fixed_header output_hdr;
};


struct net_device_output{
	string name;
	vector< string > output_port;
	vector< struct header_constraint > hc;
	vector< struct header_transition_relation >  htr;
};
*/
/*
struct fixed_header{
	string src_addr;
	string dst_addr;
	uint8_t src_port;	
	uint8_t dst_port;	
	_uint8_t protocol;
};
*/
/*
struct ec_transition_tree_node{
	struct ec_transition_tree_node *ettn[5];

	int num;
	string device;

	unsigned int src_ec;
	unsigned int transit_ec;
};

struct ec_transition_tree{
	struct ec_transition_tree_node *root;
};
*/

static unsigned long current_ec_id = 1;
static unsigned long current_transition_ec_id = 1;
static unsigned long tentative_id = 1000000000;

static unordered_map< unsigned long, map< string , pair < string, string > > > ec_id_to_ordered_path;
static unordered_map< string, unsigned long > path_to_ec_id;
static unordered_map< unsigned long, vector< struct header_constraint_vec *> > ec_id_to_header_constraint;
static vector< struct header_transition_relation >  global_htr;
static unordered_map< string, pair< string, string > > directed_topology;
static unordered_map< string, vector< string > > device_to_output_ports;
//static unordered_map< string, unordered_map< unsigned long, vector< string > > > ec_id_to_next_edges;
static unordered_map< string, unordered_map< unsigned long, bool > > link_labels;
//transition_id, src_ec_id, device -> 
static unordered_map< unsigned long, unordered_map< unsigned long, unordered_map< string, unsigned long >  > > ec_transition_map;
static unordered_map< string, struct net_device * > name_to_ndev;
static unordered_map< string, pair< string, string > > l2_topology;
static unordered_map < string, unordered_map< unsigned long, vector< string > > > ec_to_port;
//static unordered_map< string, unordered_map< unsigned long, bool > > link_labels;

//static unordered_map< unsigned long, vector< struct forwarding_link> > ec_id_to_forwarding_link;

//header to ec id が radix tree

//static unordered_map< unsigned long, string > ec_id_to_path;

//process_header_at_ndev
//single labelled graph
//incremenbtal algo

//bit computation
//update

/*
   1. dstベースのradix treeにheaderが入っていて、ec idがついている
   1. graphにラベルをつける
   1.ec idはmodify後に書き変わるec idを持ってるかも、その時はそのラベルまでincremental algo動く
   1.encap decapのグラフくっつけはbacktrackいるかも
   2.aclの持ち方とbit演算
*/

/*
	update入ってくる
	1. radix tree探索 & ec id ゲット
	2. ec idの有向グラフget
	3. invariantのチェック (ここでクエリを返す)
	4. 有向グラフのパスをhashに食わせる
	5. ec idが存在するならそのec idをつける、ないなら新しく作ってその有向グラフと紐付ける
*/


/*
	Port-based ACL
	ECでdisjoint set
*/


/*
	//Path (with map & unodered_map)
	//radix
	//single label (影響を受けるprefix)
	//graph algo
	//change_ec_id(rtree, masked.s6_addr, ec_id);
	//header const pointer
	//hdr mod ec 
	//multi-label verify (hdr mod ec multi)
	ACL && header constraint mawari
	acl & hdr mod
	hdr matching ?
	(rtreeのrotue data いらないかも)
*/

/*
	port-based ACL 二分技で打ち切り
*/


/**
	Encap後のnetworkの検証はその部分だけグラフアルゴリズムを動かせば良いが、
	もし障害が起きたらtransition関係を見ることでどのサービスが影響を受けるかをすぐにしれる
*/

using json = nlohmann::json;

void l2_topology_create(string path)
{
	/*
	std::ifstream ifs(path);

	json jf;
	
	ifs >> jf;

	pair< string, string > dev_port;

	for(int i=0;i<jf.size();i++){
		string src_device = jf[i]["node1"]["hostname"];
		string src_port = jf[i]["node1"]["interfaceName"];
		string src = src_device + src_port;
		
		dev_port.first = jf[i]["node2"]["hostname"];
		dev_port.second = jf[i]["node2"]["interfaceName"];

		l2_topology[src] = dev_port;

		src_device = jf[i]["node2"]["hostname"];
		src_port = jf[i]["node2"]["interfaceName"];
		src = src_device + src_port;

		dev_port.first = jf[i]["node1"]["hostname"];
		dev_port.second = jf[i]["node1"]["interfaceName"];

		l2_topology[src] = dev_port;
	}*/

	std::ifstream ifs(path);

	json jf;
	
	ifs >> jf;

	pair< string, string > dev_port;
	cout << jf.size() << endl;

	for(int i=0;i<jf.size();i++){
		string src = jf[i]["endpoints"][0];

		int j = 0;
		while(src[j] != ':'){
			j++;
		}
		
		string src_device = src.substr(0,j);
		string src_port = src.substr(j+1);

		src = src_device + src_port;
		
		string dst = jf[i]["endpoints"][1];

		j = 0;
                while(dst[j] != ':'){
                        j++;
                }

		string dst_device = dst.substr(0,j);
		string dst_port = dst.substr(j+1);

		dst = dst_device + dst_port;
		
		dev_port.first = dst_device;
		dev_port.second = dst_port;

		l2_topology[src] = dev_port;
		//cout << "src is  " << src << endl;
		//cout << "src_dev  " << src_device << endl;

		dev_port.first = src_device;
		dev_port.second = src_port;

		l2_topology[dst] = dev_port;
	//	cout << "dst is  " << dst << endl;
	//	cout << "dst_dev  " << dst_device << endl;
	}
}

void l2_topology_create2(string path)
{
	std::ifstream ifs(path);

	json jf;
	
	ifs >> jf;

	pair< string, string > dev_port;

	cout << jf.size() << endl;

	for(int i=0;i<jf.size();i++){
		string src = jf[i]["endpoints"][0];

		int j = 0;
		while(src[j] != ':'){
			j++;
		}
		
		string src_device = src.substr(0,j);
		string src_port = src.substr(j+1);

		if(src_device.find("node1") == 0){
			int k = 0;
			while(src_device[k] != '-'){
				k++;
			}
			src_device = "node4-"+to_string(src_device[k+1]);
		}
		else if(src_device.find("node2") == 0){
			int k = 0;
			while(src_device[k] != '-'){
				k++;
			}
			src_device = "node5-"+to_string(src_device[k+1]);
		}
		else if(src_device.find("node3") == 0){
			int k = 0;
			while(src_device[k] != '-'){
				k++;
			}
			src_device = "node6-"+to_string(src_device[k+1]);
		}
		
		src = src_device + src_port;
		
		string dst = jf[i]["endpoints"][1];

		j = 0;
                while(dst[j] != ':'){
                        j++;
                }

		string dst_device = dst.substr(0,j);
		string dst_port = dst.substr(j+1);


		if(dst_device.find("node1") == 0){
			int k = 0;
			while(dst_device[k] != '-'){
				k++;
			}
			dst_device = "node4-"+to_string(dst_device[k+1]);	
		}
		else if(dst_device.find("node2") == 0){
			int k = 0;
			while(dst_device[k] != '-'){
				k++;
			}
			dst_device = "node5-"+to_string(dst_device[k+1]);	
		}
		else if(dst_device.find("node3") == 0){
			int k = 0;
			while(dst_device[k] != '-'){
				k++;
			}
			dst_device = "node6-"+to_string(dst_device[k+1]);	
		}
		

		dst = dst_device + dst_port;
		
		dev_port.first = dst_device;
		dev_port.second = dst_port;

		l2_topology[src] = dev_port;
		//cout << "src is  " << src << endl;
		//cout << "src_dev  " << src_device << endl;

		dev_port.first = src_device;
		dev_port.second = src_port;

		l2_topology[dst] = dev_port;
		//cout << "dst is  " << dst << endl;
		//cout << "dst_dev  " << dst_device << endl;

	}
}

void l2_topology_create3(string path)
{
        std::ifstream ifs(path);

        json jf;

        ifs >> jf;

        pair< string, string > dev_port;

	cout << jf.size() << endl;

        for(int i=0;i<jf.size();i++){
                string src = jf[i]["endpoints"][0];

                int j = 0;
                while(src[j] != ':'){
                        j++;
                }

                string src_device = src.substr(0,j);
                string src_port = src.substr(j+1);

                if(src_device.find("node1") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node7-"+to_string(src_device[k+1]);
                }
                else if(src_device.find("node2") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node8-"+to_string(src_device[k+1]);
                }
                else if(src_device.find("node3") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node9-"+to_string(src_device[k+1]);
                }

                src = src_device + src_port;

                string dst = jf[i]["endpoints"][1];

                j = 0;
                while(dst[j] != ':'){
                        j++;
                }

                string dst_device = dst.substr(0,j);
                string dst_port = dst.substr(j+1);


                if(dst_device.find("node1") == 0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node7-"+to_string(dst_device[k+1]);
                }
                else if(dst_device.find("node2") ==0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node8-"+to_string(dst_device[k+1]);
                }
                else if(dst_device.find("node3") == 0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node9-"+to_string(dst_device[k+1]);
                }


                dst = dst_device + dst_port;

                dev_port.first = dst_device;
                dev_port.second = dst_port;

                l2_topology[src] = dev_port;
                //cout << "src is  " << src << endl;
                //cout << "src_dev  " << src_device << endl;

                dev_port.first = src_device;
                dev_port.second = src_port;

                l2_topology[dst] = dev_port;
        //      cout << "dst is  " << dst << endl;
        //      cout << "dst_dev  " << dst_device << endl;

        }
}



void l2_topology_create4(string path)
{
        std::ifstream ifs(path);

        json jf;

        ifs >> jf;

        pair< string, string > dev_port;

	cout << jf.size() << endl;

        for(int i=0;i<jf.size();i++){
                string src = jf[i]["endpoints"][0];

                int j = 0;
                while(src[j] != ':'){
                        j++;
                }

                string src_device = src.substr(0,j);
                string src_port = src.substr(j+1);

                if(src_device.find("node1") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node10-"+to_string(src_device[k+1]);
                }
                else if(src_device.find("node2") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node11-"+to_string(src_device[k+1]);
                }
                else if(src_device.find("node3") == 0){
                        int k = 0;
                        while(src_device[k] != '-'){
                                k++;
                        }
                        src_device = "node12-"+to_string(src_device[k+1]);
                }

                src = src_device + src_port;

                string dst = jf[i]["endpoints"][1];

                j = 0;
                while(dst[j] != ':'){
                        j++;
                }

                string dst_device = dst.substr(0,j);
                string dst_port = dst.substr(j+1);


                if(dst_device.find("node1") == 0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node10-"+to_string(dst_device[k+1]);
                }
                else if(dst_device.find("node2") ==0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node11-"+to_string(dst_device[k+1]);
                }
                else if(dst_device.find("node3") ==0){
                        int k = 0;
                        while(dst_device[k] != '-'){
                                k++;
                        }
                        dst_device = "node12-"+to_string(dst_device[k+1]);
                }


                dst = dst_device + dst_port;

                dev_port.first = dst_device;
                dev_port.second = dst_port;

                l2_topology[src] = dev_port;
                //cout << "src is  " << src << endl;
                //cout << "src_dev  " << src_device << endl;

                dev_port.first = src_device;
                dev_port.second = src_port;

                l2_topology[dst] = dev_port;
        //      cout << "dst is  " << dst << endl;
        //      cout << "dst_dev  " << dst_device << endl;

        }

}
// "" -> New, "a" -> active, "f" -> finished
//visited label global 早いかも
//unordered_map< string, unordered_map< unsigned long, string > > visited_label;
//bool verify_forwarding_loop(unsigned long affected_ec, unsigned long transit_ec, string src)
bool verify_forwarding_loop(unsigned long affected_ec, unsigned long transit_ec, string src, unordered_map< string, unordered_map< unsigned long , string > > *visited_label)
{
	//dst check
	visited_label[0][src][affected_ec] = "a";
	
	//cout << src << endl;
	//vector< string > *output_port = &device_to_output_ports[src];
	
	int current_ec;
	
	if(transit_ec != 0 && ec_transition_map[transit_ec][affected_ec][src] != 0){
		current_ec = ec_transition_map[transit_ec][affected_ec][src];
	}
	else{
		current_ec = affected_ec;
	}
	
	//map[current_ec][src] => vector< string port>
	vector< string > port = ec_to_port[src][current_ec];

	for(int i=0;i<port.size();i++){
		//cout << i << endl;
		//if(link_labels[src+port[i]][current_ec] == true){
		if(visited_label[0][directed_topology[src+port[i]].first][current_ec] == "a"){
			return false;
		}
		else if(visited_label[0][directed_topology[src+port[i]].first][current_ec].empty()){
			return verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+port[i]].first, visited_label);
				//if(verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label) == false){
			//		return false;
			//	}
		}
	}
	/*
	for(int i=0;i<device_to_output_ports[src].size();i++){
		//cout << i << endl;
		if(link_labels[src+device_to_output_ports[src][i]][current_ec] == true){
			if(visited_label[0][directed_topology[src+device_to_output_ports[src][i]].first][current_ec] == "a"){
				return false;
			}
			else if(visited_label[0][directed_topology[src+device_to_output_ports[src][i]].first][current_ec].empty()){
				return verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label);
				//if(verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label) == false){
			//		return false;
			//	}
			}
		}
	}
	*/

	visited_label[0][src][current_ec] = "f";

	
	return true;
}

//void forwarding_update(string dst_addr, string device, string port, struct radix_tree *rtree)
void forwarding_update(uint8_t *addr, int prefix_len, string device, string port, struct radix_tree *rtree)
{
	//ec idをradix treeから取ってくる
	//struct in6_addr masked;

	//int prefix_len = convert_v6addr_to_uint(dst_addr, &masked);

	//header constraintとec idが欲しい
	vector< struct ec_info *> affected_ec = get_affected_ec(rtree, addr, prefix_len);
	
	//ec id付きでグラフにdevice+port->l2_topo[device+port]の有向リンクを追加
	pair< string, string > dst;
	directed_topology[device+port] = l2_topology[device+port];

	//verify forwarding loop そのリンクを支店に
	//nexthopからチェック、現在のノードにlabelつけとk
	unordered_map< string, unordered_map< unsigned long, string > > visited_label;
	//unordered_map< unsigned long, bool > is_ec_checked;

	//cout << "affected_ec is " << affected_ec.size() << endl;

	//cout << "graph traverse" << endl;
	//auto s = std::chrono::high_resolution_clock::now();
	for(int i=0;i<affected_ec.size();i++){
		/* visited_label[device][input_port][ec_id]*/
		visited_label[device][affected_ec[i]->ec_id] = "a";

		/*
		if(is_ec_checked[affected_ec[i]->ec_id] == true){
			continue;
		}
		
		is_ec_checked[affected_ec[i]->ec_id] == true;
		*/
		//consider longest prefix match
		/*
		if(prefix_len < affected_ec[i]->hcv.hc[0][0].dst_addr.prefix_len){

			//vector< string > *links = &device_to_output_port[device];

			int j;
			for(j=0;j<device_to_output_ports[device].size();j++){
				if(link_labels[device+device_to_output_ports[device][i]][affected_ec[i]->ec_id] == true){
					break;
				}
			}
			
			if(j != device_to_output_ports[device].size()){
				continue;
			}
		}*/
	
		if(verify_forwarding_loop(affected_ec[i]->ec_id, affected_ec[i]->transit_ec_id, directed_topology[device+port].first, &visited_label) == false){
			//cout << "A forwarding loop is detedted !" << endl;
			//cout << "EC id is  " << affected_ec[i]->ec_id << endl;
		}

		/*
		string path;

		map< string, pair< string, string > > tmp_ordered_path = ec_id_to_ordered_path[affected_ec[i]->ec_id];
		tmp_ordered_path[device+port] = directed_topology[device+port];

		for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
			path += itr->first + itr->second.first + itr->second.second;
		}

		if(path_to_ec_id[path] == 0){
			cout << "aaa" << endl;
			if(verify_forwarding_loop(affected_ec[i]->ec_id, affected_ec[i]->transit_ec_id, directed_topology[device+port].first, &visited_label) == false){
				//cout << "A forwarding loop is detedted !" << endl;
				//cout << "EC id is  " << affected_ec[i]->ec_id << endl;
			}
		}
		*/
	}
	//auto e = std::chrono::high_resolution_clock::now() - s;
    //long long microseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(e).count();
    //cout << microseconds << "ns"<< endl;
	//ここでverification終了
	//return;

	//ec idをチェック
	if(affected_ec.size() == 0){
		struct ec_info eci;
		eci.ec_id = current_ec_id;
		eci.transit_ec_id = 0; /*tentative*/ 

		//struct header_constraint_vec *r_hcv_vec = set_ec_info(rtree, eci, addr, prefix_len);
		//ec_id_to_header_constraint[current_ec_id].push_back(r_hcv_vec);

		link_labels[device+port][current_ec_id] = true;

		current_ec_id++;
	}

 //s = std::chrono::high_resolution_clock::now();
	for(int i=0;i<affected_ec.size();i++){
		map< string, pair< string, string > > tmp_ordered_path = ec_id_to_ordered_path[affected_ec[i]->ec_id];
		tmp_ordered_path[device+port] = directed_topology[device+port];
		//tmp_ordered_path[device+port] = directed_topology[devcie+port].first + directed_topology[device+port].second;
		
		string path;
		for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
			path += itr->first + itr->second.first + itr->second.second;
		}
		
		if(path_to_ec_id[path] != 0){
			
			//該当のradix treeのノードのec idを書き換える
			/*該当のheader constaint削除yyyy*/		

			vector< struct header_constraint_vec *> hcv = ec_id_to_header_constraint[affected_ec[i]->ec_id];
			//vector< struct header_constraint_vec *> *hcv = &ec_id_to_header_constraint[affected_ec[i]->ec_id];
			for(int j=0;j<hcv.size();j++){
				
				if(hcv[j] == &affected_ec[i]->hcv){
					hcv.erase(hcv.begin()+j);
					break;
				}
			}

			unsigned long ec_id = path_to_ec_id[path];

			ec_id_to_header_constraint[ec_id].push_back(&affected_ec[i]->hcv);

			affected_ec[i]->ec_id = ec_id;

			//change_ec_id(rtree, masked.s6_addr, ec_id);
			
			
			/*

			for(int j=0;j<hcv->size();j++){
				if((*hcv)[j].hc.size() != affected_ec[i].hcv.hc.size()){
					continue;
				}	

				for(int k=0;k<affected_ec[i].hcv.hc.size();k++){
					if((*hcv)[j].hc[k].size() != affected_ec[i].hcv.hc[k].size()){
						break;
					}

					//おんなじかチェック
					for(int l=0;l<affected_ec[i].hcv.hc[k].size();l++){
						if((*hcv)[j].hc[k][l].src_addr.v6_addr && affected_ec[i].hcv.hc[k][l].src_addr.v6_addr == 0){
							break;
						}

						if((*hcv)[j].hc[k][l].src_addr.prefix_len != affected_ec[i].hcv.hc[k][l].src_addr.prefix_len){
							break;
						}
					
		
						if((*hcv)[j].hc[k][l].dst_addr.v6_addr && affected_ec[i].hcv.hc[k][l].dst_addr.v6_addr == 0){
							break;
						}

						if((*hcv)[j].hc[k][l].dst_addr.prefix_len != affected_ec[i].hcv.hc[k][l].dst_addr.prefix_len){
							break;
						}

						if((*hcv)[j].hc[k][l].src_port != affected_ec[i].hcv.hc[k][l].src_port){
							break;
						}

						if((*hcv)[j].hc[k][l].dst_port != affected_ec[i].hcv.hc[k][l].dst_port){
							break;
						}

						if((*hcv)[j].hc[k][l].protocol != affected_ec[i].hcv.hc[k][l].protocol){
							break;
						}
					}
					
					if(affected_ec[i].hcv.hc[k].size() != l){
						break;
					}
				}

				if(affected_ec[i].hcv.hc.size() == k){
					(*hcv)[j].erase();
					break;
				}
			}*/
		}
	else{
			path_to_ec_id[path] = current_ec_id;
			ec_id_to_ordered_path[current_ec_id] = tmp_ordered_path;

			//前のecからヘッダー制約削除
			/*
			vector< struct header_constraint_vec *> hcv = ec_id_to_header_constraint[affected_ec[i]->ec_id];
			//vector< struct header_constraint_vec *> *hcv = &ec_id_to_header_constraint[affected_ec[i]->ec_id];

			for(int j=0;j<hcv->size();j++){
				if(hcv[j] == &(affected_ec[i]->hcv)){
					hcv->erase(hcv->begin()+j);
					break;
				}
			}	
			*/

			//該当のradix treeのノードのec idを書き換える
			/*該当のheader constaint削除yyyy*/
			//ec_id_to_header_constraint[current_ec_id].push_back(&affected_ec[i]->hcv);
			affected_ec[i]->ec_id = current_ec_id;

			//change_ec_id(rtree, masked.s6_addr, current_ec_id);

			
			//for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
				//pair< string, string > dst;
				//dst.first = itr->second.first;
				//dst.second = itr->second.second;
				//if not exist
				//if exist, pass
				//directed_topology[device+port] = l2_topology[device+port];
				
				//pair< string, unsigned long> node;
				//node.first = itr->first.first;
				//node.second = eci.ec_id;
				//ec_id_to_next_edges[itr->first.first][eci.ec_id].push_back(dst.first+dst.second);
				
				//device_to_output_ports[itr->first.first].push_back(itr->first.second);
				//device_to_output_ports[itr->first.first].push_back(itr->first.second);

				link_labels[device+port][current_ec_id] = true;
				//link_labels[itr->first.first+itr->first.second+dst.first+dst.second][eci.ec_id] = true;

				//int n=0;
				/*
				while(n < itr->first.size()){
					if(itr->first[n] == 'n' && itr->first[n+1] == 'e' && itr->first[n+2] == 't'){
						break;
					}
					n++;
				}
				
				string s = itr->first.substr(0, n);
				string p = itr->first.substr(n);
				*/

				//cout << "src is " << s << " port is " << p << endl;
				//cout << "ec id is " << current_ec_id << endl; 
				ec_to_port[device][current_ec_id].push_back(port);
				//link_labels[itr->first.first+itr->first.second+dst.first+dst.second][eci.ec_id] = true;
			//}
		
			current_ec_id++;
		}	
	}
	//e = std::chrono::high_resolution_clock::now() - s;
    //microseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(e).count();
      //  cout << microseconds << "ns"<< endl;
}

bool verify_reachability(unsigned long affected_ec, unsigned long transit_ec, string src, string dst, unordered_map< string, unordered_map< unsigned long , string > > *visited_label)
{
	if(src == dst){
		return true;
	}
	
	//dst check
	visited_label[0][src][affected_ec] = "a";
	
	//vector< string > *output_port = &device_to_output_ports[src];
	
	int current_ec;
	
	if(transit_ec != 0 && ec_transition_map[transit_ec][affected_ec][src] != 0){
		current_ec = ec_transition_map[transit_ec][affected_ec][src];
	}
	else{
		current_ec = affected_ec;
	}
	
	//map[current_ec][src] => vector< string port>
	vector< string > port = ec_to_port[src][current_ec];

	for(int i=0;i<port.size();i++){
		//cout << i << endl;
		//if(link_labels[src+port[i]][current_ec] == true){
		if(visited_label[0][directed_topology[src+port[i]].first][current_ec] == "a"){
			return false;
		}
		else if(visited_label[0][directed_topology[src+port[i]].first][current_ec].empty()){
			return verify_reachability(current_ec, transit_ec, directed_topology[src+port[i]].first, dst, visited_label);
				//if(verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label) == false){
			//		return false;
			//	}
		}
	}
	/*
	for(int i=0;i<device_to_output_ports[src].size();i++){
		//cout << i << endl;
		if(link_labels[src+device_to_output_ports[src][i]][current_ec] == true){
			if(visited_label[0][directed_topology[src+device_to_output_ports[src][i]].first][current_ec] == "a"){
				return false;
			}
			else if(visited_label[0][directed_topology[src+device_to_output_ports[src][i]].first][current_ec].empty()){
				return verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label);
				//if(verify_forwarding_loop(current_ec, transit_ec, directed_topology[src+device_to_output_ports[src][i]].first, visited_label) == false){
			//		return false;
			//	}
			}
		}
	}
	*/

	visited_label[0][src][current_ec] = "f";

	
	return true;
}

//void forwarding_update(string dst_addr, string device, string port, struct radix_tree *rtree)
void forwarding_update_reach(uint8_t *addr, int prefix_len, string device, string port, struct radix_tree *rtree)
{
	//ec idをradix treeから取ってくる
	//struct in6_addr masked;

	//int prefix_len = convert_v6addr_to_uint(dst_addr, &masked);

	//header constraintとec idが欲しい
	vector< struct ec_info *> affected_ec = get_affected_ec(rtree, addr, prefix_len);
	
	//ec id付きでグラフにdevice+port->l2_topo[device+port]の有向リンクを追加
	pair< string, string > dst;
	directed_topology[device+port] = l2_topology[device+port];

	//verify forwarding loop そのリンクを支店に
	//nexthopからチェック、現在のノードにlabelつけとk
	unordered_map< string, unordered_map< unsigned long, string > > visited_label;
	//unordered_map< unsigned long, bool > is_ec_checked;

	//cout << "affected_ec is " << affected_ec.size() << endl;

	string src = "node3-1";
	string dst_dev = "node1-50";
	//string src = "node3-1";
	//string dst = "node1-50";

	for(int i=0;i<affected_ec.size();i++){
		visited_label[device][affected_ec[i]->ec_id] = "a";

		/*
		if(is_ec_checked[affected_ec[i]->ec_id] == true){
			continue;
		}
		
		is_ec_checked[affected_ec[i]->ec_id] == true;
		*/
		//consider longest prefix match
		/*
		if(prefix_len < affected_ec[i]->hcv.hc[0][0].dst_addr.prefix_len){

			//vector< string > *links = &device_to_output_port[device];

			int j;
			for(j=0;j<device_to_output_ports[device].size();j++){
				if(link_labels[device+device_to_output_ports[device][i]][affected_ec[i]->ec_id] == true){
					break;
				}
			}
			
			if(j != device_to_output_ports[device].size()){
				continue;
			}
		}*/
	
		if(verify_reachability(affected_ec[i]->ec_id, affected_ec[i]->transit_ec_id, src, dst_dev, &visited_label) == false){
			//cout << "A forwarding loop is detedted !" << endl;
			//cout << "EC id is  " << affected_ec[i]->ec_id << endl;
		}

		/*
		string path;

		map< string, pair< string, string > > tmp_ordered_path = ec_id_to_ordered_path[affected_ec[i]->ec_id];
		tmp_ordered_path[device+port] = directed_topology[device+port];

		for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
			path += itr->first + itr->second.first + itr->second.second;
		}

		if(path_to_ec_id[path] == 0){
			cout << "aaa" << endl;
			if(verify_forwarding_loop(affected_ec[i]->ec_id, affected_ec[i]->transit_ec_id, directed_topology[device+port].first, &visited_label) == false){
				//cout << "A forwarding loop is detedted !" << endl;
				//cout << "EC id is  " << affected_ec[i]->ec_id << endl;
			}
		}
		*/
	}
	
	//ここでverification終了
	//return;

	//ec idをチェック
	//if(affected_size() == 0){}

	for(int i=0;i<affected_ec.size();i++){

		map< string, pair< string, string > > tmp_ordered_path = ec_id_to_ordered_path[affected_ec[i]->ec_id];
		tmp_ordered_path[device+port] = directed_topology[device+port];
		//tmp_ordered_path[device+port] = directed_topology[devcie+port].first + directed_topology[device+port].second;
		
		string path;

		for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
			path += itr->first + itr->second.first + itr->second.second;
		}
		
		return;

		if(path_to_ec_id[path] != 0){
			
			//該当のradix treeのノードのec idを書き換える
			/*該当のheader constaint削除yyyy*/			
			vector< struct header_constraint_vec *> hcv = ec_id_to_header_constraint[affected_ec[i]->ec_id];
			//vector< struct header_constraint_vec *> *hcv = &ec_id_to_header_constraint[affected_ec[i]->ec_id];
			for(int j=0;j<hcv.size();j++){
				
				if(hcv[j] == &affected_ec[i]->hcv){
					hcv.erase(hcv.begin()+j);
					break;
				}
			}

			unsigned long ec_id = path_to_ec_id[path];

			ec_id_to_header_constraint[ec_id].push_back(&affected_ec[i]->hcv);

			affected_ec[i]->ec_id = ec_id;
		}
		else{
			path_to_ec_id[path] = current_ec_id;
			ec_id_to_ordered_path[current_ec_id] = tmp_ordered_path;

			//前のecからヘッダー制約削除
			/*
			vector< struct header_constraint_vec *> hcv = ec_id_to_header_constraint[affected_ec[i]->ec_id];
			//vector< struct header_constraint_vec *> *hcv = &ec_id_to_header_constraint[affected_ec[i]->ec_id];

			for(int j=0;j<hcv->size();j++){
				if(hcv[j] == &(affected_ec[i]->hcv)){
					hcv->erase(hcv->begin()+j);
					break;
				}
			}	
			*/

			//該当のradix treeのノードのec idを書き換える
			/*該当のheader constaint削除yyyy*/
			ec_id_to_header_constraint[current_ec_id].push_back(&affected_ec[i]->hcv);
			affected_ec[i]->ec_id = current_ec_id;

			//change_ec_id(rtree, masked.s6_addr, current_ec_id);

			
			//for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
				//pair< string, string > dst;
				//dst.first = itr->second.first;
				//dst.second = itr->second.second;
				//if not exist
				//if exist, pass
				directed_topology[device+port] = l2_topology[device+port];
				
				//pair< string, unsigned long> node;
				//node.first = itr->first.first;
				//node.second = eci.ec_id;
				//ec_id_to_next_edges[itr->first.first][eci.ec_id].push_back(dst.first+dst.second);
				
				//device_to_output_ports[itr->first.first].push_back(itr->first.second);
				//device_to_output_ports[itr->first.first].push_back(itr->first.second);

				link_labels[device+port][current_ec_id] = true;
				//link_labels[itr->first.first+itr->first.second+dst.first+dst.second][eci.ec_id] = true;

				//int n=0;
				/*
				while(n < itr->first.size()){
					if(itr->first[n] == 'n' && itr->first[n+1] == 'e' && itr->first[n+2] == 't'){
						break;
					}
					n++;
				}
				
				string s = itr->first.substr(0, n);
				string p = itr->first.substr(n);
				*/

				//cout << "src is " << s << " port is " << p << endl;
				//cout << "ec id is " << current_ec_id << endl; 
				ec_to_port[device][current_ec_id].push_back(port);
				//link_labels[itr->first.first+itr->first.second+dst.first+dst.second][eci.ec_id] = true;
			//}
		
			current_ec_id++;	
		}	
	}
}


void what_if_reach(string src_dev, string src_inf, unsigned long ecl)
{
	//dst.first = dst_dev;
	//dst.second = dst_inf;

	//l2_topology[dst_dev+dst_inf].clear();
	//l2_topology[src_dev+src_inf].clear();

	//directed_topology.erase(dst_dev+dst_inf);//.erase(src);

	directed_topology.erase(src_dev+src_inf);//.erase(dst);

	//unordered_map< unsigned long, bool > ec_labels = link_labels[src_dev+src_inf];

	string reach_src = "node1-2";
	string reach_dst = "node3-10";

	//verify_reachability(ecl, 0, reach_src, reach_dst, &visited_label);

	unordered_map< string, unordered_map< unsigned long, string > > visited_label;
	verify_reachability(ecl, 0, reach_src, reach_dst, &visited_label);
	
	//int num = 0;
	//for(auto itr = ec_labels.begin(); itr != ec_labels.end();itr++){
		//unsigned long ecl = itr->first;

//		visited_label[src_dev][ecl] = "a";

//		verify_reachability(ecl, 0, reach_src, reach_dst, &visited_label);
		//num++;
//	}
	//cout << num << endl;
}

void what_if_loop(string src_dev, string src_inf, unsigned long ecl, int i)
{
    	//auto s = std::chrono::high_resolution_clock::now();
	pair< string, string > src;
	//pair< string, string > dst;

	src.first = src_dev;
	src.second = src_inf;
	//dst.first = dst_dev;
	//dst.second = dst_inf;

	//l2_topology[dst_dev+dst_inf].clear();
	//l2_topology[src_dev+src_inf].clear();

	//directed_topology.erase(dst_dev+dst_inf);//.erase(src);
	directed_topology.erase(src_dev+src_inf);//.erase(dst);

	//forwarding_update_reach(masked.s6_addr, prefix_len, "node2-2", "eth1", rtree);
	//forwarding_update("2001:14::/64", "L2", "net1", rtree);
	//forwarding_update("2001:14::/64", "T2", "net6", rtree);
	string loop_src[5];
	//string loop_src = "node1-10";
	//string loop_dst = "node3-2";
	loop_src[0] = "node1-1";
	loop_src[1] = "node1-2";
	loop_src[2] = "node1-3";
	loop_src[3] = "node1-4";
	loop_src[4] = "node1-5";

	unordered_map< string, unordered_map< unsigned long, string > > visited_label;
	verify_forwarding_loop(ecl, 0, loop_src[i], &visited_label);
        //long long microseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(e).count();
        //cout << microseconds << endl;
	//unordered_map< unsigned long, bool > ec_labels = link_labels[src_dev+src_inf];

	//for(auto itr = ec_labels.begin(); itr != ec_labels.end();itr++){
	//	unsigned long ecl = itr->first;

	//	unordered_map< string, unordered_map< unsigned long, string > > visited_label;
//		visited_label[src_dev][ecl] = "a";
//
//		verify_forwarding_loop(ecl, 0,src_dev, &visited_label);
//	}
}

void travarse_directed_graph(struct radix_tree *rtree, struct ec_transition_tree_node *node, unsigned long ec_id, stack< unsigned long> ec_id_stack, struct net_device *ndev, uint8_t *addr)
{
	int i = 0;
	int cur_num;
	struct in6_addr masked;

	for(i=0;i<ndev->df.function.size();i++){
		if(ndev->df.function[i] == "encap"){

			//longest prefix match, header matching
			struct fixed_header *fh = get_transit_header(ndev->hmr, addr, "encap");			

			if(fh != NULL){
				int prefix_len = convert_v6addr_to_uint(fh->dst_addr, &masked);

				//encapの時はaclかかってない前提
				struct ec_info *eci = get_ec_info(rtree, masked.s6_addr);
				
				if(eci != NULL){
					cur_num = node->num;
					node->num++;

					node->ettn[cur_num] = new ec_transition_tree_node;
					node->ettn[cur_num]->device = ndev->name;
					node->ettn[cur_num]->src_ec = ec_id;

					node->ettn[cur_num]->transit_ec = eci->ec_id;

					ec_id_stack.push(ec_id);
			
					node->ettn[cur_num]->num = 0;

					break;
				}
			}
		}
		else if(ndev->df.function[i] == "decap"){
			//longest prefix match, header matching
			struct fixed_header *fh = get_transit_header(ndev->hmr, addr, "decap");			

			if(fh != NULL){
				if(!ec_id_stack.empty()){

					//struct ec_info *eci = get_ec_info(rtree, masked.s6_addr);
					unsigned long poped_ec_id = ec_id_stack.top();
					ec_id_stack.pop();

					cur_num = node->num;
					node->num++;

					node->ettn[cur_num] = new ec_transition_tree_node;
					node->ettn[cur_num]->device = ndev->name;
					node->ettn[cur_num]->src_ec = ec_id;
				
					node->ettn[cur_num]->transit_ec = poped_ec_id;
			
					node->ettn[cur_num]->num = 0;

					break;
				}
			}
		}
		else if(ndev->df.function[i] == "rewrite"){
			struct fixed_header *fh = get_transit_header(ndev->hmr, addr, "rewrite");			

			if(fh != NULL){
				//longest prefix match, header matching
				int prefix_len = convert_v6addr_to_uint(fh->dst_addr, &masked);

				struct ec_info *eci = get_ec_info(rtree, masked.s6_addr);
			
				if(eci != NULL){
					cur_num = node->num;
					node->num++;
				
					node->ettn[cur_num] = new ec_transition_tree_node;
					node->ettn[cur_num]->device = ndev->name;
					node->ettn[cur_num]->src_ec = ec_id;	
				
					node->ettn[cur_num]->transit_ec = eci->ec_id;

					node->ettn[cur_num]->num = 0;

					break;
				}
			}		

		}
	}

	for(i=0;i<device_to_output_ports[ndev->name].size();i++){
		if(link_labels[ndev->name+device_to_output_ports[ndev->name][i]][node->ettn[cur_num]->transit_ec] == true){
			struct net_device *dst_dev = name_to_ndev[directed_topology[ndev->name+device_to_output_ports[ndev->name][i]].first];
			travarse_directed_graph(rtree, node->ettn[cur_num], node->ettn[cur_num]->transit_ec, ec_id_stack, dst_dev, masked.s6_addr);
		}
	}
	
	return;
}


void rec_set_ec_transition(struct ec_transition_tree_node *ettn)
{
	int num = ettn->num;

	ec_transition_map[current_transition_ec_id][ettn->src_ec][ettn->device] = ettn->transit_ec;

	for(int i=0;i<num;i++){
		rec_set_ec_transition(ettn->ettn[i]);		
	}
	
	return;
}

void set_ec_transition(struct radix_tree *rtree, struct ec_transition_tree *ett, uint8_t *addr, int prefix)
{
	//current transition ec idをettのルートのradix treeのノードにつける
	set_transition_ec_id(rtree, addr, prefix, current_transition_ec_id, 0);

	//ecの移り変わりをdeviceにセット
	rec_set_ec_transition(ett->root);

	current_transition_ec_id++;
}

void create_equivalence_class(struct radix_tree *rtree, struct net_device *ndev, int device_num, string path)
{
	int prefix_len;
	string header;
	string src, dst;
	vector< string > header_vec;
	
	//vector< struct header_constraint > header_const;

	header_vec = search_headers(rtree);

	for(int i=0;i<device_num;i++){
		name_to_ndev[ndev[i].name] = ndev;
		//device_to_output_ports[ndev->name] = ndev->port;
	}

	l2_topology_create(path);
	l2_topology_create2("./clab_100_3/topology.json");
	l2_topology_create3("./clab_100_4/topology.json");
	l2_topology_create4("./clab_100_5/topology.json");

	//topology merge
	 //top def for top
    int inf_idx = 1;
    for(int i=192;i<200;i++){
		pair< string, string > dst;
		dst.first = ndev[i].name;
		dst.second = "eth100";
		l2_topology["top1eth"+to_string(inf_idx)] = dst;

		pair< string, string > src;
		src.first = "top1";
		src.second = "eth"+to_string(inf_idx);

		l2_topology[dst.first+dst.second] = src;

        inf_idx++;
    }

    for(int i=298;i<301;i++){
        pair< string, string > dst;
		dst.first = ndev[i].name;
		dst.second = "eth100";
		l2_topology["top1eth"+to_string(inf_idx)] = dst;

		pair< string, string > src;
		src.first = "top1";
		src.second = "eth"+to_string(inf_idx);

		l2_topology[dst.first+dst.second] = src;

        inf_idx++;
    }

    for(int i=398;i<401;i++){
        pair< string, string > dst;
        dst.first = ndev[i].name;
       	dst.second = "eth100";
         l2_topology["top1eth"+to_string(inf_idx)] = dst;

                pair< string, string > src;
                src.first = "top1";
                src.second = "eth"+to_string(inf_idx);

                l2_topology[dst.first+dst.second] = src;

        inf_idx++;
    }
	
    for(int i=498;i<501;i++){
        pair< string, string > dst;
        dst.first = ndev[i].name;
       	dst.second = "eth100";
         l2_topology["top1eth"+to_string(inf_idx)] = dst;

                pair< string, string > src;
                src.first = "top1";
                src.second = "eth"+to_string(inf_idx);

                l2_topology[dst.first+dst.second] = src;

        inf_idx++;
    }
	
	//addr_to_device_create(ipath);

	//cout << "topo: " << l2_topology.size() << endl;

	//assign

	for(int i=0;i<header_vec.size();i++){
		map< string , pair< string, string > > ordered_path;
		//vector< struct net_device_output > ndo_vec;
		//vector< string > acl_device_vec;
		struct in6_addr masked;
		struct header_constraint_vec hcv_vec;

		//struct fowarding_link tmp_fwd_link;
		//vector< struct fowarding_link > fwd_link_vec;
		
		//vector< vector < struct header_constraint > > hcv_vec;
		
		//1. get each header 
		header = header_vec[i];

			//cout << "HEADER " << header << endl;
		prefix_len = convert_v6addr_to_uint(header, &masked);
		//cout << "HEADER " << header << endl;

		if(header == "default"){
			continue;
		}

		if(prefix_len == -1){
			cout << "error at v6 addr convert" << endl;
			return;
		}

		if(header.empty()){
			cout << "error: header null" << endl;
			break;
		}

		string path;

		//2. check forwarding behavior of the header
		for(int j=0;j<device_num;j++){

			struct net_device_output ndo;

			//forward, rewrite, drop, encap, decap
			//3. process the header in each device
			// output: output port, header constraint, transition relation (in netdevice output)
			//cout <<  j << endl;
			//cout << ndev[j].name << endl;
			ndo = process_header_at_ndev(&ndev[j], header, masked.s6_addr, prefix_len);
			//cout << ndev[j].name << endl;
			//ndo_vec.push_back(ndo);

			for(int n=0;n<ndo.output_port.size();n++){
				device_to_output_ports[ndev[j].name].push_back(ndo.output_port[n]);
			}
			
			//acl null check
			if(ndo.hc.size() != 0 ){
				//if null then continue;
			}		
					
			//4. header constraint
			if(ndo.hc.size() != 0){
				cout << "hc happen" << endl;
				hcv_vec.hc.push_back(ndo.hc);
				//acl_device_vec.push_back(ndo.name);
			}

			//4. record header transition relation
			if(ndo.htr.size() != 0){
				for(int k=0;k<ndo.htr.size();k++){
					global_htr.push_back(ndo.htr[k]);
				}
				//cout << "add trans. relation" << endl;
			}

			//4. record one hop forwarding
			if(ndo.output_port.size() != 0){

				src = ndo.name;
				for(int k=0;k<ndo.output_port.size();k++){
					
					//record oredered path

					//src += ndo.output_port[k];
					
					src = ndo.name + ndo.output_port[k];
					ordered_path[src] = l2_topology[src];
					
					//ordered_path[src] = l2_topology[src].first + l2_topology[src].second;
				
					//record forwarding link
					/*
					tmp_fwd_link.src_device = ndo.name;
					tmp_fwd_link.src_port = ndo.output_port[k];
					tmp_fwd_link.dst_device = l2_topology.first;
					tmp_fwd_link.dst_port = l2_topology.second;
					
					fwd_link_vec.push_back(tmp_fwd_link);

					*/
				}
				//sort(src);
				//path += src;
				//ordered_path[src] = l2_topology[src];
			}
		}
		
		struct header_constraint_vec hc_vec;

		//5. bit computation for header constraint
		//port-based acl
		/*****************hennko*************/
		if(hcv_vec.hc.size() > 1){
			//bit computation
			//hc_vec = hc_vec1 & hc_vec2;
			//if null after bit computation, no graph
		}
		else if(hcv_vec.hc.size() == 1){
			hc_vec.hc = hcv_vec.hc;
		}
		else{
			/*
			struct header_constraint temp_hc;

			struct prefix src_tmp_pr;
			src_tmp_pr.prefix_len = 0;
			temp_hc.src_addr = src_tmp_pr;

			struct prefix tmp_pr;
			memcpy(tmp_pr.v6_addr, masked.s6_addr, sizeof(masked.s6_addr));
			tmp_pr.prefix_len = prefix_len;
			temp_hc.dst_addr = tmp_pr;

			temp_hc.src_port = 0;
			temp_hc.dst_port = 0;
			temp_hc.protocol = 0;
			
			hc_vec.hc.push_back(temp_hc);
			*/
		}

		//6. compute ec id 

		//sort(path);

		//6.1 enumurate path
		
		for(auto itr = ordered_path.begin(); itr != ordered_path.end(); itr++){
			path += itr->first + itr->second.first + itr->second.second;
		}

		
		//6.2 ec calc
		if(path_to_ec_id[path] != 0 && hc_vec.hc.size() != 0){
			unsigned long ec_id = path_to_ec_id[path];

			//insert the header (hc_vec) and its ec id into rtree
			struct ec_info eci;
			eci.ec_id = ec_id;
			eci.transit_ec_id = 0; /*tentative*/
			eci.hcv = hc_vec;

			struct header_constraint_vec *r_hcv_vec = set_ec_info(rtree, eci, masked.s6_addr, prefix_len);
			ec_id_to_header_constraint[ec_id].push_back(r_hcv_vec);
		}
		else if(path_to_ec_id[path] == 0 && hc_vec.hc.size() == 0){

			path_to_ec_id[path] = current_ec_id;
			ec_id_to_ordered_path[current_ec_id] = ordered_path;
			//ec_id_to_fwd_link[current_ec_id] = fwd_link_vec;

			//insert the header and its ec id into rtree
			struct ec_info eci;
			eci.ec_id = current_ec_id;
			eci.transit_ec_id = 0; /*tentative*/
			eci.hcv = hc_vec; 

			struct header_constraint_vec *r_hcv_vec = set_ec_info(rtree, eci, masked.s6_addr, prefix_len);
			ec_id_to_header_constraint[current_ec_id].push_back(r_hcv_vec);

			current_ec_id++;

			//single labelled graphに追加
			//unordered_map< string, pair< string, string > > directed_topology;
			//unordered_map< pair< string, unsigned long >, vector< string > > ec_id_to_next_edges;
			//unordered_map< string, unordered_map< unsigned long, bool > > link_labels;
						

			/*エッジの情報に従って、有向グラフを作る*/
			/*新しいエッジの時は、エッジの追加とラベルをつける*/
			/*エッジが存在するときは、普通にラベルつけるだけ*/		
			for(auto itr = ordered_path.begin(); itr != ordered_path.end(); itr++){

				//pair< string, string > dst;
				//dst.first = itr->second.first;
				//dst.second = itr->second.second;
				//if not exist
				//if exist, pass
				//if(directed_topology[itr->first.first+itr->first.second] == ""){
				if(directed_topology[itr->first].first.empty()){
					directed_topology[itr->first] = itr->second;
					//directed_topology[itr->first.first+itr->first.second] = dst;
				}
				
				//pair< string, unsigned long> node;
				//node.first = itr->first.first;
				//node.second = eci.ec_id;
				//ec_id_to_next_edges[itr->first.first][eci.ec_id].push_back(dst.first+dst.second);
				
				//device_to_output_ports[itr->first.first].push_back(itr->first.second);

				link_labels[itr->first][eci.ec_id] = true;
			
				int n=0;
				while(n < itr->first.size()){
					if(itr->first[n] == 'e' && itr->first[n+1] == 't' && itr->first[n+2] == 'h'){
						break;
					}
					n++;
				}
				
				string s = itr->first.substr(0, n);
				string p = itr->first.substr(n);

				//cout << "src is " << s << " port is " << p << endl;
				//cout << "ec id is " << eci.ec_id << endl;
				ec_to_port[s][eci.ec_id].push_back(p);
				//link_labels[itr->first.first+itr->first.second+dst.first+dst.second][eci.ec_id] = true;
			}
			
		}
		else{
			/*
			cout << "-------------------" << endl;
			cout << "no header can exist" << endl;
			cout << "ec id is " << path_to_ec_id[path] << endl;
			cout << "-------------------" << endl;
			*/
		}

		struct header_constraint_vec normal_hcv;
		struct header_constraint_vec negation_hcv;
		unordered_map< string, bool > acl_device_to_truth;

		//7. create forwarding behavior of the rest header constraint
		for(int l=0;l < (1 << hcv_vec.hc.size())-1 ;l++){

			for(int b=0;b<hcv_vec.hc.size();b++){
				if(l &  (1 << b)){
					normal_hcv.hc.push_back(hcv_vec.hc[b]);
				}
				else{
					negation_hcv.hc.push_back(hcv_vec.hc[b]);
				}
			}

			//2分木に実装変更
			/*
			if(normal_hcv.hc.size() == 0){
				for(int t=1;t<negation_hcv.hc.size();t++){
					for(int p=0;p<negation_hcv.hc[t].size();p++){
						negation_hcv.hc[0].push_back(hcv_vec.hc[t][p]);
						acl_device_to_truth[hcv_vec.hc[t][p].device] = true;
					}
				}

				//check forwarding behavior
				//vector< struct forwarding_link > tmp_fwd_link_vec = fwd_link_vec;
				map< string, string > tmp_ordered_path = ordered_path;
				path = "";

				//for(int t=0;t<tmp_fwd_link_vec.size();t++){
				for(auto itr = tmp_ordered_path.begin(); itr != tmp_ordered_path.end(); itr++){
					if(acl_device_to_truth.count(tmp_fwd_link_vec[t].src_device) != 0){
						tmp_fwd_link_vec.erase(tmp_fwd_link_vec.begin()+t);
					}
				}

				for(auto itr = ordered_path.begin(); itr != ordered_path.end(); itr++){
					path += itr->first + itr->second;
				}

				if(path_to_ec_id[path] != 0 && hc_vec.hc.size() != 0){
					ec_id = path_to_ec_id[path];
					ec_id_to_header_constraint[ec_id].push_back(hc_vec);
				}
				else if(hc_vec.size() != 0){
					path_to_ec_id[path] = current_ec_id;
					ec_id_to_fwd_link[current_ec_id] = fwd_link_vec;
					ec_id_to_header_constraint[current_ec_id].push_back(hc_vec);
					current_ec_id++;
				}
			}
			else{
				for(int b=0;b<normal_hcv.hc.size()-1;b++){
					//bit computation &
				}
			
				for(int b=0;b<negation_hcv.hc.size();b++){
					//A & not B　の繰り返し
				}
	
			}
			*/
		}
	}	


	//merge ec graph with global htr
	//やらないといけないのはhdr to ec idのvector？
	struct in6_addr input_masked;	
	struct in6_addr output_masked;	

	//encap -> rewrite -> decap
	//
	//if htr->option_field != NULL

	//encap, rewriteのルールを集める
	//encapからrewriteの順で、modが起こる場所から幅優先探索
	//探索初めに, current: mod後のheader, stack: mod前のheaderをつむ
	//encapがきたら, stackにつむ
	//rewriteがきたら、current書き換える
	//decapがきたら、stackの一番上をpopし、curerntに書き換える
	//stack == NULLの状態でdecapが起きたらundefinedなのでそこで終了
	//最終的にgetしたec idのトレースを元に、radix treeの各ノードにec idを書き込む

	stack< struct fixed_header > header_stack;

	for(int i=0;i<global_htr.size();i++){
		cout << "global" << endl;

		struct net_device *src_dev;
		string output_port;
		int prefix_len;
		vector< struct route_data > rd;
		struct header_transition_relation *htr = &global_htr[i];

		vector< struct ec_label_transition_relation > vec_ecl_tr;		
		
		if(htr->type == "encap" || htr->type == "rewrite"){
			struct ec_label_transition_relation ecl_tr;

			struct in6_addr src, masked;
			prefix_len = convert_v6addr_to_uint(htr->input_hdr.dst_addr, &src);
			vector< struct ec_info *> eci_vec = get_affected_ec(rtree, src.s6_addr, prefix_len);
			//cout << "trans device : " << htr->device << endl;
			//cout << "input hdr trans addr: " << htr->input_hdr.dst_addr << endl;
			//cout << "input hdr ec label: " << eci_vec[0]->ec_id << endl;
			//cout << "eci vec size: " << eci_vec.size() << endl;

			for(int j=0;j<eci_vec.size();j++){

				/*
				struct ec_transition_tree ett;
				ett.root = new ec_transition_tree_node;
				ett.root->device = htr->device;
				ett.root->src_ec = eci_vec[j]->ec_id;

				ett.root->num = 0;
				*/
				
				
				prefix_len = convert_v6addr_to_uint(htr->output_hdr.dst_addr, &masked);
				vector<struct ec_info *> eci = get_affected_ec(rtree, masked.s6_addr, prefix_len);
				if(eci.size() == 0){
					cout << "-------------------error---------------" << endl;
					cout << "trans device : " << htr->device << endl;
					cout << "output hdr trans addr: " << htr->output_hdr.dst_addr << endl;
					break;
				}
				//cout << "output hdr trans addr: " << htr->output_hdr.dst_addr << endl;
				//cout << "output hdr ec label: " << eci->ec_id << endl;

				ecl_tr.vertex = htr->device;
				if(ecl_tr.input_ecl == 0){
					ecl_tr.input_ecl = tentative_id;
					tentative_id++;
				}
				else{
					ecl_tr.input_ecl = eci_vec[j]->ec_id;
				}
				ecl_tr.type = htr->type;
				ecl_tr.output_ecl = eci[0]->ec_id;

				vec_ecl_tr.push_back(ecl_tr);

				src_dev = name_to_ndev[htr->device];
				//rd = radix_tree_lookup(ndev->fib, masked.s6_addr);
				//vector< string > output_port = rd[0].inf;
			
				/*
				for(int k=0;k<device_to_output_ports[src_dev->name].size();k++){
					if(link_labels[src_dev->name+device_to_output_ports[src_dev->name][k]][eci->ec_id] == true){
						struct net_device *dst_dev = name_to_ndev[directed_topology[src_dev->name+(device_to_output_ports[src_dev->name][k])].first];
						//ouput_headerを入れたい
						stack< unsigned long > ec_id_stack;
						travarse_directed_graph(rtree, ett.root, ett.root->transit_ec, ec_id_stack, dst_dev, masked.s6_addr);
					}
				}*/

				//hashに追加
				for(int sk = 0; sk < vec_ecl_tr.size();sk++){
					ec_transition_map[current_transition_ec_id][vec_ecl_tr[sk].input_ecl][vec_ecl_tr[sk].vertex] = vec_ecl_tr[sk].output_ecl;
					//set_transition_ec_id(rtree, src.s6_addr, 64, current_transition_ec_id, 0);
					current_transition_ec_id++;
				}
				
				

				//ec_id_translation[transition_id][ec_id] = transit_ec;
				//出来上がったtreeを深さ優先探索でtransition関係をget
				//set_ec_transition(rtree, &ett, src.s6_addr, prefix_len);
				//startのheaderにtransition idを降る

				//今のデバイスの持ってるtransitionk関係を出力
				//もしすでに同じec transitionが存在したら、
				//もし存在するtransitionで, prev_fhと同じだったら
				//長い方をとる？
	
				
			}
		}
						
	}
	
		cout << "number of hash is " << ec_transition_map.size() << endl;
//1		cout << "number of path_to_ec_id hash is " << path_to_ec_id.size() << endl;
}

vector< struct header_constraint >  bit_and_operation(vector< struct header_constraint > *hc1, vector< struct header_constraint > *hc2)
{
	int flag = 0;

	vector< struct header_constraint > tmp_hc;

	for(int i=0;i<hc1->size();i++){
		for(int j=0;j<hc2->size();j++){
			//src addr

			/*
			if((hc1->at(i).src_addr.prefix_len == hc2->at(i).src_addr.prefix_len)){
				if(hc1->at(i).src_addr.v6_addr ^ hc2->at(i).src_addr.v6_addr != 0){
					flag = 1;
					break;
				}
			}
			*/		
			
			//dst addr
			

			//src port
			if(hc1->at(i).src_port != hc2->at(j).src_port){
				flag = 1;
				break;
			}

			//dst port
			if(hc1->at(i).dst_port != hc2->at(j).dst_port){
				flag = 1;
				break;
			}
			//protocol number
			if(hc1->at(i).protocol != hc2->at(j).protocol){
				flag = 1;
				break;
			}
		}
	}	

	/*
	if(flag == 1){
		return ;
	}

	return */
}
