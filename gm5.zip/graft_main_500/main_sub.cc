#include <fstream>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <list>
#include <sys/time.h>
#include <ctime>
#include <chrono>
#include <arpa/inet.h>
#include <unistd.h>
#include <unordered_map>
#include <algorithm>

#include "./include/forwarding_radix_tree_v6.h"
#include "./include/acl_radix_tree.h"
#include "./include/hm_radix_tree.h"
#include "./include/device.h"
#include "./include/ec.h"
#include "./include/util.h"

using namespace std;

static unordered_map< string, string > prefix_to_net_device;

int main()
{
	/*define each device model*/
	/*assosiate the table with the function*/
		

	/*push fib & acl to radix tree*/
	 //string router[4] = {"r1","r2","r3","r4"};
       // auto s = std::chrono::high_resolution_clock::now();

	 //string router[52] = {"SP20","SP19","SP18","SP17","SP16","SP15","SP14","SP13","SP12","SP11","SP10","SP9","SP8","SP7","SP6","SP5","SP4","SP3","SP2","SP1","L16","L15","L14","L13","L12","L11","L10","L9","L8","L7","L6","L5","L4","L3","L2","L1","T8","T7","T6","T5","T4","T3","T2","T1","S8","S7","S6","S5","S4","S3","S2","S1"};

	/*
		1. Service Function Chaningやtrafic engneeringのためのSRv6などのネットワーク技術が考慮できること
		2. ECのmergeを形式的に言える
		3. prefix-base, l3上のl4の同一グラフへの埋め込みをうまく言う
	*/


	/*
	 * 1. fibをradix treeに詰める 
	 * 1. functionの順序をセット
	 * 2. 各デバイスごとに, radix treeのleafに存在するprefixごとにそのdstを持つpacketを流し、どの入力ポートと出力ポートがつ	　　　　　　　ながるかをチェックする。ある入力ポートとある出力ポートがつながる場合は、出力ポートと繋がっている他のデバイスの
	　　　入力ポートのリンクを貼る
	   2. ACLがあった場合は、prefix_to_acl(prefix) = acl_rules ということをする
              prefix_to_acl(prefix) = acl_rulesのacl_rulesが空じゃないなら新しいacl_ruleと&をとる(iteration)
              prefix_to_acl(prefix) がからなら、新しいacl_rulesを代入する
　　　　　 2. encap/decap用のglobal stackを作る? hdr_to_hm_stack(hdr) = stack (during iteration)
	      rewriteはそのままグラフをくっつけるだけで良いはず
           3. 2の過程を全デバイスで回して、path-based ecを作る
              hdr_to_ec_id(prefix or five tupels) = ec_id
              ec_id_to_hdr(ec_id) = hdr
	      のunordered_mapを作る
	   4. single labelled graphを作る (各ec_idのラベルをリンクに埋め込む)
           5. incremental verificationのアルゴリズムを作る
	   6. updateに対する対応を作る
	 */
	string dir = "clab_200";
	string dir2 = "clab_100_3";
	string dir3 = "clab_100_4";
	string dir4 = "clab_100_5";

	int t1 = 128;
	int t2 = 64;
	int t3 = 8;

	int t4 = 64;
	int t5 = 32;
	int t6 = 4;

	int t7 = 64;
	int t8 = 32;
	int t9 = 4;

	int t10 = 64;
	int t11 = 32;
	int t12 = 4;

	int device_num = t1 + t2 + t3;
	int another_devnum = t4+t5+t6;
	int another_devnum2 = t7+t8+t9;
	int another_devnum3 = t10+t11+t12;
	int top_dev = 1;
    	int allDev = device_num+another_devnum+another_devnum2+another_devnum3+top_dev;


	struct net_device ndev[allDev];
	
	/*setting for network devices*/
	
	string func_type[5];
	vector< string > ports;
	//struct net_device ndev[4];

	//l2 topology definition
	
	/*
	for(int i=0;i<52;i++){
		ndev[i].name = router[i];
		func_type[0] = "forward";
		set_net_device(&ndev[i], router[i], ports);
		set_dataplane_pipeline(&ndev[i], func_type, 1);
	}
	*/
	
	/*
	ndev[0].name = router[0];
	func_type[0] = "forward";
	func_type[1] = "encap";
	set_net_device(&ndev[0], router[0], ports);
	set_dataplane_pipeline(&ndev[0], func_type, 2);

	ndev[51].name = router[51];
	func_type[0] = "decap";
	func_type[1] = "forward";
	set_net_device(&ndev[51], router[51], ports);
	set_dataplane_pipeline(&ndev[51], func_type, 2);
	*/

	

	int idx=0;
	for(int i=0;i<t1;i++){
		ndev[idx].name = "node1-" + to_string(i+1);
		idx += 1;
	}
	
	for(int i=0;i<t2;i++){
		ndev[idx].name = "node2-" + to_string(i+1);
		idx += 1;
	}

	for(int i=0;i<t3;i++){
		ndev[idx].name = "node3-" + to_string(i+1);
		idx += 1;
	}
	
	 for(int i=0;i<t4;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node4-" + to_string(i+1);
            idx++;
    }

        for(int i=0;i<t5;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
            ndev[idx].name = "node5-" +to_string(i+1);
            idx++;
        }

        int t6_idx = idx;
        for(int i=0;i<t6;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node6-" +to_string(i+1);
            idx++;
        }

		for(int i=0;i<t7;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node7-" + to_string(i+1);
            idx++;
    }

        for(int i=0;i<t8;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
            ndev[idx].name = "node8-" +to_string(i+1);
            idx++;
        }

        int t9_idx = idx;
        for(int i=0;i<t9;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node9-" +to_string(i+1);
            idx++;
        }

	
	for(int i=0;i<t10;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node10-" + to_string(i+1);
            idx++;
    }

        for(int i=0;i<t11;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
            ndev[idx].name = "node11-" +to_string(i+1);
            idx++;
        }

        int t12_idx = idx;
        for(int i=0;i<t12;i++){
            //File f = new File("/Users/siiba/Downloads/atomic_predicates_for_transformers_20191231/src/transformer/clab_clos_100/clab-3tier-node1-"+i);
           ndev[idx].name = "node12-" +to_string(i+1);
            idx++;
        }


	ndev[allDev-1].name = "top1";

	int hdr_trans_i = 0;

	for(int i=0;i<allDev;i++){
		/*
		func_type[0] = "forward";
		
		if(ndev[i].name.find("node11") != 0 && ndev[i].name.find("node12") != 0 && ndev[i].name.find("node1") == 0 || ndev[i].name.find("node4") == 0 || ndev[i].name.find("node7") == 0 || ndev[i].name.find("node10") == 0){
			
			cout << ndev[i].name << endl;
			func_type[1] = "rewrite";		
			set_net_device(&ndev[i], ndev[i].name, ports);
			set_dataplane_pipeline(&ndev[i], func_type, 2);
		}
		else{
			set_net_device(&ndev[i], ndev[i].name, ports);
			set_dataplane_pipeline(&ndev[i], func_type, 1);
		}*/
		func_type[0] = "forward";
		set_net_device(&ndev[i], ndev[i].name, ports);
		set_dataplane_pipeline(&ndev[i], func_type, 1);
	}

	/*	
	for(int i=0;i<4;i++){
		ndev[i].name = router[i];
	}*/

	//port設定

	// 1. 各デバイスのnetwork functionとその順序を設定してもらう
	/*
	string func_type[5];
	vector< string > ports;
	
	func_type[0] = "forward";
	ports.push_back("p1");
	set_net_device(&ndev[0], router[0], ports);
	set_dataplane_pipeline(&ndev[0], func_type, 1);

	func_type[0] = "encap";
	func_type[1] = "forward";
	ports.push_back("p2");
	set_net_device(&ndev[1], router[1], ports);
	set_dataplane_pipeline(&ndev[1], func_type, 2);

	func_type[0] = "decap";
	func_type[1] = "forward";
	set_net_device(&ndev[2], router[2], ports);
	set_dataplane_pipeline(&ndev[2], func_type, 2);

	ports.clear();	
	func_type[0] = "forward";
	ports.push_back("p1");
	set_net_device(&ndev[3], router[3], ports);
	set_dataplane_pipeline(&ndev[3], func_type, 1);
	*/

	
        // 1. forwarding,ルールをradix treeに突っ込む

	struct radix_tree *rtree;
	rtree = new radix_tree;
	rtree->root = NULL;

		//fib merge

    for(int i=0;i<device_num;i++){
        read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir+ "/clab-3tier-"+ndev[i].name+"/v6route.txt");
		ndev[i].fib = new radix_tree;
		ndev[i].fib->root = NULL;
		read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir+"/clab-3tier-"+ndev[i].name+"/v6route.txt");

		if(ndev[i].name.find("node1") == 0){
			//ndev[i].hmr = new hm_radix_tree;
			//ndev[i].hmr->root = NULL;
			
			/*
			for(int hv=1;hv<20+1;hv++){
				for(int j=1;j<hdr_trans_i+1;j++){
					struct hm_data hd;
					struct fixed_header sfh;
					struct fixed_header ofh;

					sfh.dst_addr = "2001:" + to_string(j) + "::/64";
					ofh.dst_addr = "2001:" + to_string(hv) + "::/64";
			
					hd.action = "rewrite";
				
					pair< struct fixed_header, struct fixed_header > ph;
					ph.first = sfh;
					ph.second = ofh;
					hd.htr = ph;
	
					int prefix;
					struct in6_addr v6_addr;
					prefix = convert_v6addr_to_uint(sfh.dst_addr, &v6_addr);
			
					hm_radix_tree_add(ndev[i].hmr, hd, prefix, v6_addr.s6_addr);
				}
			}*/
		}

		 for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());   
			int prefix = 64;
			string addr = "2002:" + to_string(j) + "::/64";
			struct in6_addr v6addr;
			convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node1") == 0){  
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth1");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
 
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

					p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

					p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

					p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
            else if(ndev[i].name.find("node2") == 0){
                struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth130");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
            else if(ndev[i].name.find("node3") == 0){
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth100");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
        }	

		 for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());   
			int prefix = 64;
			string addr = "2003:" + to_string(j) + "::/64";
			struct in6_addr v6addr;
			convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node1") == 0){  
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth1");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
                        

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

					p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

					p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       


					p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

            }
            else if(ndev[i].name.find("node2") == 0){
                struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth130");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

				p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
            else if(ndev[i].name.find("node3") == 0){
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth100");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
        }

	for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());
                        int prefix = 64;
                        string addr = "2004:" + to_string(j) + "::/64";
                        struct in6_addr v6addr;
                        convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node1") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth1");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                        p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                        p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                        p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

            }
            else if(ndev[i].name.find("node2") == 0){
                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth130");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       

                                p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
            else if(ndev[i].name.find("node3") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth100");
                                rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);                       
            }
        }
			
    }

	cout << 2 << endl;
	//2
	for(int i=device_num;i<device_num+another_devnum;i++){

		if(ndev[i].name.find("node4") == 0){
			//ndev[i].hmr = new hm_radix_tree;
			//ndev[i].hmr->root = NULL;
			
			/*
			for(int hv=1;hv<20+1;hv++){
				for(int j=1;j<hdr_trans_i+1;j++){
					struct hm_data hd;
					struct fixed_header sfh;
					struct fixed_header ofh;

					sfh.dst_addr = "2002:" + to_string(j) + "::/64";
					ofh.dst_addr = "2001:" + to_string(hv) + "::/64";
			
					hd.action = "rewrite";
				
					pair< struct fixed_header, struct fixed_header > ph;
					ph.first = sfh;
					ph.second = ofh;
					hd.htr = ph;
	
					int prefix;
					struct in6_addr v6_addr;
					prefix = convert_v6addr_to_uint(sfh.dst_addr, &v6_addr);
			
					hm_radix_tree_add(ndev[i].hmr, hd, prefix, v6_addr.s6_addr);
				}
			}*/
		}	

			if(ndev[i].name.find("node4") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir2+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir2+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			else if(ndev[i].name.find("node5") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir2+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir2+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			if(ndev[i].name.find("node6") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir2+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir2+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}

			 for(int j=1;j<8704+1;j++){
					int prefix = 64;
					string addr = "2001:" + to_string(j) + "::/64";
					struct in6_addr v6addr;
					convert_v6addr_to_uint(addr,&v6addr);
                    
                    if(ndev[i].name.find("node4") ==0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth1");
						rd.inf = p;
						radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth3");
						rd.inf = p;
						radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
              
                    }
                    else if(ndev[i].name.find("node5") ==0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth80");
						rd.inf = p;
						radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth50");
						rd.inf = p;
						radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
                    else if(ndev[i].name.find("node6") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth100");
						rd.inf = p;
						radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
            }


		 for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());   
			int prefix = 64;
			string addr = "2003:" + to_string(j) + "::/64";
			struct in6_addr v6addr;
			convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node4") == 0){  
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth1");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node5") == 0){
                struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth130");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node6") == 0){
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth100");
				rd.inf = p;
				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
	}

	for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());
                        int prefix = 64;
                        string addr = "2004:" + to_string(j) + "::/64";
                        struct in6_addr v6addr;
                        convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node4") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth1");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node5") == 0){
                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth130");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node6") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth100");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
        }
	}


		cout << 3 << endl;
		//3
		for(int i=device_num+another_devnum;i<device_num+another_devnum+another_devnum2;i++){
			if(ndev[i].name.find("node7") == 0){
			/*
				ndev[i].hmr = new hm_radix_tree;
				ndev[i].hmr->root = NULL;
			
				for(int hv=1;hv<20+1;hv++){
					for(int j=1;j<hdr_trans_i+1;j++){
						struct hm_data hd;
						struct fixed_header sfh;
						struct fixed_header ofh;

						sfh.dst_addr = "2003:" + to_string(j) + "::/64";
						ofh.dst_addr = "2001:" + to_string(hv) + "::/64";
			
						hd.action = "rewrite";
				
						pair< struct fixed_header, struct fixed_header > ph;
						ph.first = sfh;
						ph.second = ofh;
						hd.htr = ph;
	
						int prefix;
						struct in6_addr v6_addr;
						prefix = convert_v6addr_to_uint(sfh.dst_addr, &v6_addr);
			
						hm_radix_tree_add(ndev[i].hmr, hd, prefix, v6_addr.s6_addr);
					}
				}
			*/
			}		
			if(ndev[i].name.find("node7") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir3+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir3+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			else if(ndev[i].name.find("node8") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir3+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir3+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			if(ndev[i].name.find("node9") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir3+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir3+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}

			 for(int j=1;j<8704+1;j++){
					int prefix = 64;
					string addr = "2001:" + to_string(j) + "::/64";
					struct in6_addr v6addr;
					convert_v6addr_to_uint(addr,&v6addr);
                    
                    if(ndev[i].name.find("node7") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth1");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth3");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
              
                    }
                    else if(ndev[i].name.find("node8") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth80");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth50");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
                    else if(ndev[i].name.find("node9") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth100");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
            }


		 for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());   
			int prefix = 64;
			string addr = "2002:" + to_string(j) + "::/64";
			struct in6_addr v6addr;
			convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node7") == 0){  
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth1");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node8") == 0){
                struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth130");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node9") == 0){
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth100");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
	}	
	for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());
                        int prefix = 64;
                        string addr = "2004:" + to_string(j) + "::/64";
                        struct in6_addr v6addr;
                        convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node7") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth1");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node8") == 0){
                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth130");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node9") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth100");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
        }
	}
		
		cout << 4 << endl;
	
		for(int i=device_num+another_devnum+another_devnum2;i<allDev-1;i++){
			if(ndev[i].name.find("node10") == 0){
				//ndev[i].hmr = new hm_radix_tree;
				//ndev[i].hmr->root = NULL;
			
				/*
				for(int hv=1;hv<20+1;hv++){
					for(int j=1;j<hdr_trans_i+1;j++){
						struct hm_data hd;
						struct fixed_header sfh;
						struct fixed_header ofh;

						sfh.dst_addr = "2004:" + to_string(j) + "::/64";
						ofh.dst_addr = "2001:" + to_string(hv) + "::/64";
			
						hd.action = "rewrite";
				
						pair< struct fixed_header, struct fixed_header > ph;
						ph.first = sfh;
						ph.second = ofh;
						hd.htr = ph;
	
						int prefix;
						struct in6_addr v6_addr;
						prefix = convert_v6addr_to_uint(sfh.dst_addr, &v6_addr);
			
						hm_radix_tree_add(ndev[i].hmr, hd, prefix, v6_addr.s6_addr);
					}
				}*/
			}				
			if(ndev[i].name.find("node10") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir4+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir4+ "/clab-3tier-node1-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			else if(ndev[i].name.find("node11") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir4+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir4+ "/clab-3tier-node2-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}
			if(ndev[i].name.find("node12") == 0){
				int idx=0;
				while(true){
					if(ndev[i].name[idx] == '-'){
						break;
					}
					idx++;
				}

				read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir4+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
				ndev[i].fib = new radix_tree;
				ndev[i].fib->root = NULL;
				read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir4+ "/clab-3tier-node3-"+ to_string(ndev[i].name[idx+1])+"/v6route.txt");
			}

			 for(int j=1;j<8704+1;j++){
					int prefix = 64;
					string addr = "2001:" + to_string(j) + "::/64";
					struct in6_addr v6addr;
					convert_v6addr_to_uint(addr,&v6addr);
                    
                    if(ndev[i].name.find("node10") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth1");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth3");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
              
                    }
                    else if(ndev[i].name.find("node11") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth80");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                        p.pop_back();
						p.push_back("eth50");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
                    else if(ndev[i].name.find("node12") == 0){
                         struct route_data rd;
						rd.addr = addr;
						rd.device = ndev[i].name;
						vector<string> p;
						p.push_back("eth100");
						rd.inf = p;
                				radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                    }
            }


		 for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());   
			int prefix = 64;
			string addr = "2002:" + to_string(j) + "::/64";
			struct in6_addr v6addr;
			convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node10") == 0){  
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth1");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

					p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node11") == 0){
                struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth130");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
                        
				p.pop_back();
				p.push_back("eth3");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth5");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth7");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth9");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

				p.pop_back();
				p.push_back("eth11");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node12") == 0){
				struct route_data rd;
				rd.addr = addr;
				rd.device = ndev[i].name;
				vector<string> p;
				p.push_back("eth100");
				rd.inf = p;
                		radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
	}	
	for(int j=1;j< 2176+1;j++){
                        //System.out.println(Inet6Address.getByName(addr).getHostAddress());
                        int prefix = 64;
                        string addr = "2003:" + to_string(j) + "::/64";
                        struct in6_addr v6addr;
                        convert_v6addr_to_uint(addr,&v6addr);

            //System.out.println(result);
            if(ndev[i].name.find("node10") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth1");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                        p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node11") == 0){
                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth130");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth3");
                                rd.inf = p;
                radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth5");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth7");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth9");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);

                                p.pop_back();
                                p.push_back("eth11");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
            else if(ndev[i].name.find("node12") == 0){
                                struct route_data rd;
                                rd.addr = addr;
                                rd.device = ndev[i].name;
                                vector<string> p;
                                p.push_back("eth100");
                                rd.inf = p;
                                radix_tree_add(ndev[i].fib,rd,prefix,v6addr.s6_addr);
            }
        }
	}


	
	ndev[allDev-1].fib = new radix_tree;
	ndev[allDev-1].fib->root = NULL;
	

	//top
	for(int p=1;p<t3+1;p++){
			string addr = "2001::/16";
            struct route_data rd;
			rd.addr = addr;
			rd.device = "top1";
			vector<string> pp;
			pp.push_back("eth"+to_string(p));
			rd.inf = pp;

			struct in6_addr v6addr;
			int prefix = convert_v6addr_to_uint(addr,&v6addr);
			radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);
    }

	 for(int p=1;p<t6+1;p++){
			string addr = "2002::/16";
            struct route_data rd;
			rd.addr = addr;
			rd.device = "top1";
			vector<string> pp;
			pp.push_back("eth"+to_string(t3+p));
			rd.inf = pp;

			struct in6_addr v6addr;
			int prefix = convert_v6addr_to_uint(addr,&v6addr);
			radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);
    }

	for(int p=1;p<t9+1;p++){
			string addr = "2003::/16";
            struct route_data rd;
			rd.addr = addr;
			rd.device = "top1";
			vector<string> pp;
			pp.push_back("eth"+to_string(t3+t6+p));
			rd.inf = pp;

			struct in6_addr v6addr;
			int prefix = convert_v6addr_to_uint(addr,&v6addr);
			radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);
    }
	for(int p=1;p<t12+1;p++){
			string addr = "2004::/16";
            struct route_data rd;
			rd.addr = addr;
			rd.device = "top1";
			vector<string> pp;
			pp.push_back("eth"+to_string(t3+t6+t9+p));
			rd.inf = pp;

			struct in6_addr v6addr;
			int prefix = convert_v6addr_to_uint(addr,&v6addr);
			radix_tree_add(rtree,rd,prefix,v6addr.s6_addr);
    }

	/*
        for(int i=0;i<100;i++){
                read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./fib/"+ndev[i].name+"/v6route.txt");
		ndev[i].fib = new radix_tree;
		ndev[i].fib->root = NULL;
		read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./fib/"+ndev[i].name+"/v6route.txt");
        }
	*/
	/*header modification rules*/

	/*各デバイスのif addrをaddr_to_device mapに入れる*/

	/*
	* 2. 各デバイスごとに, radix treeのleafに存在するprefixごとにそのdstを持つpacketを流し、どの入力ポートと出力ポートがつ 　　　　　　　ながるかをチェックする。ある入力ポートとある出力ポートがつながる場合は、出力ポートと繋がっている他のデバイスの
        　　　入力ポートのリンクを貼る
           2. ACLがあった場合は、prefix_to_acl(prefix) = acl_rules ということをする
              prefix_to_acl(prefix) = acl_rulesのacl_rulesが空じゃないなら新しいacl_ruleと&をとる(iteration)
              prefix_to_acl(prefix) がからなら、新しいacl_rulesを代入する
　　　　　 2. encap/decap用のglobal stackを作る? hdr_to_hm_stack(hdr) = stack (during iteration)
              rewriteはそのままグラフをくっつけるだけで良いはず
	*/

	//ec_id, ec_path_condition, ec_path, header_stack

	create_equivalence_class(rtree, ndev, allDev, "./" + dir + "/topology.json");

	//create_equivalence_class(rtree, ndev, 52, "/home/siiba/new_hm_aware_dpv/fib/topology/topology.json");

	//merge_ecs_with_header_modification()

	//initial_property_check
	
	for(int i=0;i<device_num;i++){
		radix_tree_free(ndev[i].fib);
	}

	/*search radix tree and compute fwd graph*/	
	/*check whethere there is an EC id for the path */
	/*if yes, mark the id in the leaf*/
	/*if not, create new ec id and mark ec id in the leaf into the pathset*/
	//compute_forwarding_graph(rtree, acl_rtree, hm_rtree, router);

	/*push header modification rules to a header modification table*/
	//read_header_modification_rules_to_radix_tree();
	/*merge ecs with header modification rules*/
	//merge_ecs();

	/*update */
	//cout << "update" << endl;
	struct in6_addr masked;

	string nonexv6addr[3];
	nonexv6addr[0] = "a011:2::/64";
	nonexv6addr[1] = "a011:10::/64";
	//nonexv6addr[2] = "a011:20::/64";

	string exv6addr[3];
	exv6addr[0] = "2001:2::/64";
	exv6addr[1] = "2001:10::/64";
	//exv6addr[2] = "2001:20::/64";

	pair< string , string > fail[10];
	
	fail[0].first = "node1-2";
	fail[0].second = "eth12";

	fail[1].first = "node2-2";
	fail[1].second = "eth2";

	fail[2].first = "node2-10";
	fail[2].second = "eth10";

	fail[3].first = "node1-2";
	fail[3].second = "eth1";

	fail[4].first = "node1-2";
	fail[4].second = "eth1";
	
	int prefix_len = convert_v6addr_to_uint(exv6addr[1], &masked);
    	auto s = std::chrono::high_resolution_clock::now();
	//forwarding_update_reach(masked.s6_addr, prefix_len, "node1-2", "eth1", rtree);
	//vector< struct ec_info *> affected_ec = get_affected_ec(rtree, masked.s6_addr, prefix_len);
	//cout << affected_ec[0]->ec_id << endl;
	//for(int i=0;i<5;i++){
	//	what_if_loop(fail[i].first,fail[i].second,affected_ec[0]->ec_id,i);
	//}
	forwarding_update(masked.s6_addr, prefix_len, "node2-2", "eth1", rtree);
	//forwarding_update("2001:14::/64", "L2", "net1", rtree);
	//forwarding_update("2001:14::/64", "T2", "net6", rtree);
	auto e = std::chrono::high_resolution_clock::now() - s;
        long long microseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(e).count();
        cout << microseconds << endl;
	cout << "end !" << endl;
	radix_tree_free(rtree);
	/*
	for(int i=0;i<device_num;i++){
		radix_tree_free(ndev[i].fib);
	}*/
	//acl_radix_tree_free(acl_rtree);
	//hm_radix_tree_free(hm_rtree);


	//auto e = std::chrono::high_resolution_clock::now() - s;
        //long long microseconds = std::chrono::duration_cast<std::chrono::microseconds>(e).count();
        //cout << microseconds << "μs"<< endl;

	return 0;
}
