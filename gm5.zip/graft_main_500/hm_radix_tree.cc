#include <iostream>
#include <utility>
#include <unordered_set>
#include <unordered_map>
#include <fstream>
#include <arpa/inet.h>

#include "./include/hm_radix_tree.h"

#define BIT_TEST(k, b)  (((uint8_t *)(k))[(b) >> 3] & (0x80 >> ((b) & 0x7)))

using namespace std;

vector< pair< struct fixed_header, struct fixed_header> > rec_hm_radix_tree_get_transition(struct hm_radix_tree_node *node, uint8_t *addr, int prefix, string action, int depth)
{
	if(prefix == depth && node != NULL){
		//cout << "get trans !" << endl;
		vector< struct hm_data > hm_data_vec = node->data;
		vector< pair< struct fixed_header, struct fixed_header> > output_htr_vec;
		
		for(int i=0;i<hm_data_vec.size();i++){
			if(hm_data_vec[i].action == action){
				output_htr_vec.push_back(hm_data_vec[i].htr);
			}
		}

		return output_htr_vec;
	}
	else if(prefix == depth || node == NULL){
		vector< pair< struct fixed_header, struct fixed_header> > output_htr_vec;
		return output_htr_vec;
	}

	if(BIT_TEST(addr,depth)){
		return rec_hm_radix_tree_get_transition(node->right, addr, prefix, action, depth+1);
	}
	else{
		return rec_hm_radix_tree_get_transition(node->left, addr, prefix, action, depth+1);
	}
}

vector< pair< struct fixed_header, struct fixed_header > > hm_radix_tree_get_transition(struct hm_radix_tree *rtree, uint8_t *addr, int prefix, string action)
{
	return rec_hm_radix_tree_get_transition(rtree->root, addr, prefix, action, 0);	
}

struct fixed_header *rec_get_transit_header(struct hm_radix_tree_node *node, struct hm_radix_tree_node *prev_node, uint8_t *addr, string action, int depth)
{
	if(node == NULL){
		if(prev_node){
			for(int i=0;i<node->data.size();i++){
				if(node->data[i].action == action){
					return &node->data[i].htr.second;
				}
			}

			return NULL;
		}
		else{
			cout << "Can not find a transit header" << endl;
			return NULL;
		}
	}

	if(!node->data.empty()){
		prev_node = node;
	}
	

	if(BIT_TEST(addr,depth)){
		return rec_get_transit_header(node->right, prev_node, addr, action, depth+1);
	}
	else{
		return rec_get_transit_header(node->left, prev_node, addr, action, depth+1);
	}
}

struct fixed_header *get_transit_header(struct hm_radix_tree *rtree, uint8_t *addr, string action)
{
	struct hm_radix_tree_node *prev_node; 
	return rec_get_transit_header(rtree->root, prev_node, addr, action, 0);	
}

//for first rule insertion
int radd(struct hm_radix_tree_node **node, struct hm_data data, int prefix, uint8_t *addr, int depth)
{
	struct hm_radix_tree_node *new_node;

	if(*node == NULL){
		new_node = new hm_radix_tree_node;
		if(new_node == NULL){
			printf("failed to allocate radix_tree_node at radd() .\n");
		}
		*node = new_node;
		(*node)->right = NULL;
		(*node)->left = NULL;
	}
	
	if(prefix == depth){
		(*node)->data.push_back(data);
		return 0;
	}
	else{
		if(BIT_TEST(addr,depth)){
			//cout << "1" ;
			return radd(&(*node)->right, data, prefix, addr, depth+1);
		}
		else{
			//cout << "0";
			return radd(&(*node)->left, data, prefix, addr, depth+1);
		}
	}
}

int hm_radix_tree_add(struct hm_radix_tree *rtree, struct hm_data data, int prefix, uint8_t *addr)
{
	//cout << "start" << endl;
	//printf("%hhx\n",addr[0]);
	return radd(&rtree->root, data, prefix, addr, 0);
}

int hm_radix_tree_shrink(struct hm_radix_tree_node **cur)
{
	int lret;
	int rret;

	if(cur == NULL){
		return 0;
	}

	lret = hm_radix_tree_shrink(&(*cur)->left); 
	rret = hm_radix_tree_shrink(&(*cur)->right);

	if(lret || rret){
		return 1;
	}
	else{
		if((*cur)->left == NULL && (*cur)->right == NULL){
			free(*cur);
			*cur = NULL;
			return 0;
		}
		else{
			return 1;
		}
	}
}

void rdelete(struct hm_radix_tree_node **node, int prefix, uint8_t *addr, int depth)
{
	if(*node == NULL){
		printf("No item to delete\n");
		return;
	}

	if(prefix == depth){
		if(!(*node)->data.empty()){
			hm_radix_tree_shrink(node);
			return;
		}
		else{
			return;
		}
	}
	else{
		if(BIT_TEST(addr,depth)){
			return rdelete(&(*node)->right, prefix, addr, depth+1);
		}
		else{
			return rdelete(&(*node)->left, prefix, addr, depth+1);
		}

	}
}

void hm_radix_tree_delete(struct hm_radix_tree *rtree, int prefix, uint8_t *addr)
{
	return rdelete(&rtree->root, prefix, addr, 0);
}

vector<hm_data>* rlookup(struct hm_radix_tree_node *node, struct hm_radix_tree_node *prev_node, uint8_t *addr, int depth)
{
	if(node == NULL){
		if(prev_node){
			return &prev_node->data;
		}
		else{
			//printf("Can not find a item\n");
			return NULL;
		}
	}

	if(!node->data.empty()){
		prev_node = node;
	}

	if(BIT_TEST(addr,depth)){
		return rlookup(node->right, prev_node, addr, depth+1);
	}
	else{
		return rlookup(node->left, prev_node, addr, depth+1);
	}

}

vector<hm_data> *hm_radix_tree_lookup(struct hm_radix_tree *rtree, uint8_t *addr)
{
	return rlookup(rtree->root, NULL, addr, 0);
}

void hm_radix_tree_free_node(struct hm_radix_tree_node *node)
{
	if(node != NULL){
		hm_radix_tree_free_node(node->left);
		hm_radix_tree_free_node(node->right);
		free(node);
	}
}

int hm_radix_tree_free(struct hm_radix_tree *tree)
{
	hm_radix_tree_free_node(tree->root);

	if(tree){
		free(tree);
	}
	return 0;
}

void hm_radix_tree_init(struct hm_radix_tree *rtree)
{
	if(rtree == NULL){
		rtree = new hm_radix_tree;
	}
	else{
		printf("the radix tree is already allocated.\n");

	}

	/*
	for(int i=MAX_EC_NUMBER;i>0;i--){
		ec_index_set.push_back(i);	
	}*/

	/*
	ecs_pointer.current_index = 0;
	ecs_pointer.pointer = NULL;
	*/
}
