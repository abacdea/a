max=4
for ((i=0; i < $max; i++)); do
    make
    ./main >> ../graft_exp_data/500/whif_loop/time.txt
done
