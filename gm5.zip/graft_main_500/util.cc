#include <iostream>
#include <utility>
#include <fstream>
#include <unordered_map>
#include <arpa/inet.h>
#include <nlohmann/json.hpp>

#include "./include/util.h"

using namespace std;
using json = nlohmann::json;

void l2_topology_create(unordered_map< string, pair < string, string > > l2_topology, string path)
{
	std::ifstream ifs(path);

	json jf;
	
	ifs >> jf;

	pair< string, string > dev_port;

	for(int i=0;i<jf.size();i++){
		string src_device = jf[i]["node1"]["hostname"];
		string src_port = jf[i]["node1"]["interfaceName"];
		string src = src_device + src_port;
		
		dev_port.first = jf[i]["node2"]["hostname"];
		dev_port.second = jf[i]["node2"]["interfaceName"];

		l2_topology[src] = dev_port;

		src_device = jf[i]["node2"]["hostname"];
		src_port = jf[i]["node2"]["interfaceName"];
		src = src_device + src_port;

		dev_port.first = jf[i]["node1"]["hostname"];
		dev_port.second = jf[i]["node1"]["interfaceName"];

		l2_topology[src] = dev_port;
	}
}

bool inet6_lnaof(struct in6_addr *dst, struct in6_addr *src, struct in6_addr *netmask)
{
        bool has_lna = false;

        for (unsigned i = 0; i < 16; i++) {
                dst->s6_addr[i] = src->s6_addr[i] & netmask->s6_addr[i];
                has_lna |= (0 != (src->s6_addr[i] & !netmask->s6_addr[i]));
        }

        return has_lna;
}

int convert_v6addr_to_uint(string addr,struct in6_addr *masked)
{
	int ret = 0;

	int i = 0;
	while(addr[i] != '/'){
		i++;
	}
	
	string str_prefix = addr.substr(0,i);
	if(str_prefix == "default"){
		return 1;
	}
	
	const char *prefix = str_prefix.c_str();

	int len = 0;
	for(int j=i+1;j<addr.length();j++){
		len++;
	}

	int k = 0;
	char prefix_array[len];
	for(int j=i+1;j<addr.length();j++){
		prefix_array[k] = addr[j];
		k++;
	}

	int prefix_len = atoi(prefix_array);
	
	struct in6_addr res;
	ret = inet_pton(AF_INET6, prefix, &res);
	if(ret != 1){
		cout << addr << endl;
		cout << str_prefix << endl;
		perror("inet_pton: ");
		return -1;
	}

	/*
	for(i=0;i<16;i++){
		printf("%hhx",res.s6_addr[i]);
	}
	cout << endl;
	*/

	struct sockaddr_in6 netmask;
	for (long i = prefix_len, j = 0; i > 0; i -= 8, ++j){
  		netmask.sin6_addr.s6_addr[j] = i >= 8 ? 0xff : (uint64_t)(( 0xffU << ( 8 - i ) ) & 0xffU );
	}

	inet6_lnaof(masked,&res,&netmask.sin6_addr);
	
	return prefix_len;
}
