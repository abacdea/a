#include <fstream>
#include <iostream>
#include <string>
#include <cstring>
#include <vector>
#include <list>
#include <sys/time.h>
#include <ctime>
#include <chrono>
#include <arpa/inet.h>
#include <unordered_map>
#include <algorithm>

#include "./include/forwarding_radix_tree_v6.h"
#include "./include/acl_radix_tree.h"
#include "./include/hm_radix_tree.h"
#include "./include/device.h"
#include "./include/ec.h"
#include "./include/util.h"

using namespace std;

static unordered_map< string, string > prefix_to_net_device;

int main()
{
	string dir = "nsdi_clos500";


	int torp = 7;
        int leafp = 7;
        int spinep = 16;

        int toru = 48;
        int leafu = 16;
        int spineu = 4;

        int device_num = 512;

        struct net_device ndev[device_num+1];
	string func_type[5];
	vector< string > ports;

       int idx=0;
        for(int i=1;i<=torp;i++){
                for(int j=1;j<=toru;j++){
                        ndev[idx].name = "tor"+to_string(i)+"-"+to_string(j);
                        idx += 1;
                }
        }

        for(int i=1;i<=leafp;i++){
                for(int j=1;j<=leafu;j++){
                        ndev[idx].name = "leaf"+to_string(i)+"-"+to_string(j);
                        idx += 1;
                }
        }

        for(int i=1;i<=spinep;i++){
                for(int j=1;j<=spineu;j++){
                        ndev[idx].name = "spine"+to_string(i)+"-"+to_string(j);
                        idx += 1;
                }
        }

        for(int i=0;i<device_num;i++){
                func_type[0] = "forward";
                set_net_device(&ndev[i], ndev[i].name, ports);
                set_dataplane_pipeline(&ndev[i], func_type, 1);
        }	

	for(int i=0;i<device_num;i++){
		func_type[0] = "forward";
		set_net_device(&ndev[i], ndev[i].name, ports);
		set_dataplane_pipeline(&ndev[i], func_type, 1);
	}

	struct radix_tree *rtree;
	rtree = new radix_tree;
	rtree->root = NULL;


        for(int i=0;i<device_num;i++){
                        read_linux_fib_to_radix_tree(ndev[i].name,rtree,NULL,"./"+ dir+"/"+ndev[i].name+"/v6route.txt");
                        ndev[i].fib = new radix_tree;
                        ndev[i].fib->root = NULL;
                        read_linux_fib_to_radix_tree(ndev[i].name,ndev[i].fib, NULL, "./"+ dir+"/"+ndev[i].name+"/v6route.txt");
        }
                        
	create_equivalence_class(rtree, ndev, device_num, "./" + dir + "/topology.json");

	/*update */
	//cout << "update" << endl;
	struct in6_addr masked;

	string nonexv6addr[3];
	nonexv6addr[0] = "a011:2::/64";
	nonexv6addr[1] = "a011:10::/64";
	//nonexv6addr[2] = "a011:20::/64";

	string exv6addr[3];
	exv6addr[0] = "2002:1::/64";
	exv6addr[1] = "2001:10::/64";
	//exv6addr[2] = "2001:20::/64";


	int prefix_len = convert_v6addr_to_uint(exv6addr[0], &masked);
    	auto s = std::chrono::high_resolution_clock::now();
	forwarding_update(masked.s6_addr, prefix_len, "tor1-1", "net1", rtree);
	//forwarding_update("2001:14::/64", "L2", "net1", rtree);
	//forwarding_update("2001:14::/64", "T2", "net6", rtree);
	auto e = std::chrono::high_resolution_clock::now() - s;
        long long microseconds = std::chrono::duration_cast<std::chrono::nanoseconds>(e).count();
        cout << microseconds << endl;

	radix_tree_free(rtree);
	for(int i=0;i<device_num;i++){
		radix_tree_free(ndev[i].fib);
	}
	//acl_radix_tree_free(acl_rtree);
	//hm_radix_tree_free(hm_rtree);


	//auto e = std::chrono::high_resolution_clock::now() - s;
        //long long microseconds = std::chrono::duration_cast<std::chrono::microseconds>(e).count();
        //cout << microseconds << "μs"<< endl;

	return 0;
}
